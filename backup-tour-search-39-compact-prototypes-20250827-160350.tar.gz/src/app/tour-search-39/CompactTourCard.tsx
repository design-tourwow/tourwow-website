'use client';

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { SearchIndexTour } from './types';
import { 
  Clock, MapPin, Star, Users, Heart, Zap, ChevronDown, 
  Calendar, ArrowRight
} from 'lucide-react';

// Utility hook for auto-expand with progress
const useAutoExpand = (threshold = 3000, enabled = true) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isInView, setIsInView] = useState(false);
  const timerRef = useRef<NodeJS.Timeout>();
  const progressRef = useRef<NodeJS.Timeout>();
  const elementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!enabled || !elementRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
            setIsInView(true);
            
            // Start progress animation
            let currentProgress = 0;
            const increment = 100 / (threshold / 100);
            
            progressRef.current = setInterval(() => {
              currentProgress += increment;
              setProgress(Math.min(currentProgress, 100));
              
              if (currentProgress >= 100) {
                clearInterval(progressRef.current);
              }
            }, 100);

            // Auto expand after threshold
            timerRef.current = setTimeout(() => {
              setIsExpanded(true);
              setProgress(100);
            }, threshold);
          } else {
            setIsInView(false);
            setProgress(0);
            
            // Clear timers
            if (timerRef.current) clearTimeout(timerRef.current);
            if (progressRef.current) clearInterval(progressRef.current);
          }
        });
      },
      { threshold: 0.5 }
    );

    observer.observe(elementRef.current);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressRef.current) clearInterval(progressRef.current);
      observer.disconnect();
    };
  }, [threshold, enabled]);

  const toggleExpand = useCallback(() => {
    setIsExpanded(!isExpanded);
    setProgress(0);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (progressRef.current) clearInterval(progressRef.current);
  }, [isExpanded]);

  return { isExpanded, progress, isInView, elementRef, toggleExpand, setIsExpanded };
};

interface CompactTourCardProps {
  tour: SearchIndexTour;
  prototype?: 1 | 2 | 3 | 4 | 5;
  isWishlisted?: boolean;
  onWishlistToggle?: (tourId: string) => void;
  onQuickBook?: (tour: SearchIndexTour) => void;
}

// Prototype 1: Minimal Card with Slide Expand
const Prototype1: React.FC<CompactTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const { isExpanded, progress, elementRef, toggleExpand } = useAutoExpand();
  const formatPrice = (price: number) => price.toLocaleString('th-TH');
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0;

  return (
    <div ref={elementRef} className="relative mb-6">
      {/* Progress indicator */}
      {progress > 0 && progress < 100 && (
        <div className="absolute -inset-1 rounded-2xl overflow-hidden z-10 pointer-events-none">
          <div 
            className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-blue-600/20"
            style={{
              transform: `scaleX(${progress / 100})`,
              transformOrigin: 'left',
              transition: 'transform 0.1s linear'
            }}
          />
        </div>
      )}

      <div 
        className={`
          bg-white rounded-xl border transition-all duration-500 ease-out
          ${isExpanded ? 'shadow-2xl border-blue-500/50' : 'shadow-md border-gray-200 hover:shadow-lg'}
        `}
      >
        {/* Compact View - Horizontal List Style */}
        <div 
          className="flex items-center p-2 cursor-pointer hover:bg-gray-50/50 transition-colors"
          onClick={toggleExpand}
        >
          {/* Compact Image */}
          <div className="relative w-16 h-16 md:w-20 md:h-20 flex-shrink-0 rounded overflow-hidden">
            <Image
              src={tour.media.hero_image}
              alt={tour.title}
              fill
              className="object-cover"
            />
            {hasDiscount && (
              <span className="absolute top-0 left-0 bg-red-500 text-white text-xs px-1 py-0.5 rounded-br">
                -{tour.pricing.discount_percentage}%
              </span>
            )}
          </div>

          {/* Compact Info - List Style */}
          <div className="flex-1 ml-3 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-sm line-clamp-1 text-gray-900 mb-1">
                  {tour.title}
                </h3>
                <div className="flex items-center gap-3 text-xs text-gray-600 mb-1">
                  <span className="flex items-center">
                    <svg className="w-3 h-3 text-yellow-400 fill-current mr-1" viewBox="0 0 20 20">
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg>
                    {tour.rating}
                  </span>
                  <span>{tour.duration_days}วัน{tour.nights}คืน</span>
                  <span className="text-blue-600 font-medium">
                    ฿{formatPrice(tour.pricing.base_price)}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center ml-2">
                {progress > 0 && progress < 100 && (
                  <div className="w-6 h-6 mr-2">
                    <div className="w-full h-1 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500 transition-all duration-100"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <div className="text-xs text-center text-blue-600 font-medium mt-0.5">
                      {Math.round(progress)}%
                    </div>
                  </div>
                )}
                <button
                  className={`
                    p-1 rounded transition-all duration-300 text-gray-500
                    ${isExpanded ? 'rotate-180 bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}
                  `}
                  aria-label={isExpanded ? 'ซ่อนรายละเอียด' : 'ดูรายละเอียด'}
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Expanded Content - Copy from tour-search-35 */}
        {isExpanded && (
          <div className="border-t border-gray-100">
            {/* Image Section */}
            <div className="relative h-48 md:h-52">
              <Image
                src={tour.media.hero_image}
                alt={tour.title}
                fill
                className="object-cover"
                sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
              />
              
              {/* Overlays */}
              <div className="absolute top-3 left-3 right-3 flex justify-between items-start">
                {hasDiscount && (
                  <span className="inline-flex items-center justify-center border-radius-9999px font-size-0.75rem font-weight-600 line-height-1.25 padding-0.25rem-0.5rem white-space-nowrap text-transform-none bg-red-100 text-red-600 text-sm px-3 py-1 rounded-full font-bold">
                    ลด {tour.pricing.discount_percentage}%
                  </span>
                )}
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onWishlistToggle?.(tour.metadata.id);
                  }}
                  className="bg-white/90 backdrop-blur-sm rounded-full p-2"
                  aria-label={isWishlisted ? 'ลบจากรายการโปรด' : 'เพิ่มในรายการโปรด'}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
                </button>
              </div>
              
              {/* Duration Badge */}
              <div className="absolute bottom-3 left-3">
                <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-sm font-medium flex items-center">
                  <Clock className="w-4 h-4 mr-1 text-blue-600" />
                  {tour.duration_days}วัน{tour.nights}คืน
                </div>
              </div>
              
              {/* Availability Alert */}
              {tour.availability.available_seats <= 5 && (
                <div className="absolute bottom-3 right-3">
                  <span className="inline-flex items-center justify-center border-radius-9999px font-size-0.75rem font-weight-600 line-height-1.25 padding-0.25rem-0.5rem white-space-nowrap text-transform-none bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                    เหลือ {tour.availability.available_seats} ที่!
                  </span>
                </div>
              )}
            </div>
            
            {/* Content Section */}
            <div className="p-4">
              {/* Title */}
              <h3 className="font-semibold text-gray-900 text-base mb-2 line-clamp-2 leading-tight">
                {tour.title}
              </h3>
              
              {/* Promotional Text */}
              <div className="text-sm text-blue-600 mb-3 line-clamp-2 leading-relaxed">
                {(() => {
                  switch (tour.location.country) {
                    case 'ญี่ปุ่น':
                      return 'สัมผัสวัฒนธรรมแบบดั้งเดิม ชมซากุระบาน หรือใบไม้เปลี่ยนสี พร้อมลิ้มรสอาหารญี่ปุ่นแท้ เยือนเกียวโต นารา โตเกียว และชิราคาวาโกะ นั่งรถไฟชินคันเซน สุดยอดประสบการณ์ที่ไม่ลืม'
                    case 'เกาหลีใต้':
                      return 'เที่ยวเกาหลีสไตล์ K-Pop ช้อปปิ้งเมืองโซล ลิ้มรสกิมจิและบาร์บีคิวเกาหลีแท้ เดินเล่นในถนนมยองดง ใสใสดง เชคอิน N Seoul Tower และเกาะเชจู สวรรค์แห่งธรรมชาติ'
                    case 'ไต้หวัน':
                      return 'เจียวเฟิ่น จิ่วเฟิ่น และตลาดกลางคืนชื่อดัง ครบครันในราคาสุดคุ้ม ชิมอาหารข้างทาง เที่ยวทะเลสาบสุริยันจันทรา ชมความงามของหุบเขาทาโรโกะ และช้อปปิ้งย่านไทเป'
                    case 'ยุโรป':
                      return 'เยือนยุโรปเก่าแก่ สถาปัตยกรรมสวยงาม และวัฒนธรรมที่หลากหลาย ชมหอไอเฟล ลอนดอนบริดจ์ และโคลอสเซียม เดินทางสะดวกด้วยรถไฟความเร็วสูง พักโรงแรมกลางเมือง'
                    case 'จีน':
                      return 'สำรวจกำแพงเมืองจีน พระราชวังต้องห้าม และความทันสมัยของเซี่ยงไฮ้ เยือนสุสานทหารดินเผาที่ซีอาน ขี่จักรยานในปักกิ่งเก่า และชมมหานครสมัยใหม่ เซินเจิ้น กวางโจว'
                    case 'สิงคโปร์':
                      return 'เมืองแห่งอนาคต สวนสนุกระดับโลก และอาหารหลากหลายวัฒนธรรม Universal Studios Gardens by the Bay และโรงแรมทรายที่มารีน่าเบย์แซนด์ส ช้อปปิ้งย่านออร์ชาร์ด รด.'
                    case 'มาเลเซีย':
                      return 'ปีนัง กัวลาลัมเปอร์ และลังกาวี สวรรค์แห่งการท่องเที่ยวเอเชีย เยือนถ้ำบาตู เพโทรนาส ทาวเวอร์ และสะพานท้องฟ้าลังกาวี ลิ้มรสอาหารมาเลย์ จีน อินเดีย ต้นตำรับ'
                    case 'ฮ่องกง':
                      return 'ดิสนีย์แลนด์ วิคตอเรีย ฮาร์เบอร์ และการช้อปปิ้งสุดเจ๋งในใจกลางเอเชีย นั่งเคเบิลคาร์ขึ้นเขาวิคตอเรียพีค ชิมติ่มซำแท้ ๆ ย่านต์ไซซา หลานไกฟง และมองก๊ก'
                    default:
                      return `สำรวจ${tour.location.country || 'ปลายทางใหม่'}อันงดงาม เที่ยวสุดคุ้มกับโปรแกรมคุณภาพ มีไกด์ท้องถิ่นคอยดูแล พักโรงแรมมาตรฐาน รับประทานอาหารท้องถิ่นรสชาติดี พร้อมประสบการณ์ท่องเที่ยวที่ไม่ลืม`
                  }
                })()}
              </div>
              
              {/* Location & Highlights */}
              <div className="mb-4">
                <div className="flex items-center flex-wrap gap-2">
                  <div className="flex items-center text-gray-600 text-sm mr-2">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{tour.location.country}</span>
                  </div>
                  {tour.highlights.slice(0, 3).map((highlight, idx) => (
                    <span key={idx} className="inline-flex items-center justify-center border-radius-9999px font-size-0.75rem font-weight-600 line-height-1.25 padding-0.25rem-0.5rem white-space-nowrap text-transform-none bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-full">
                      {typeof highlight === 'string' ? highlight : highlight.text}
                    </span>
                  ))}
                  {tour.highlights.length > 3 && (
                    <span className="text-xs text-gray-500 px-2 py-1">
                      +{tour.highlights.length - 3} อื่นๆ
                    </span>
                  )}
                </div>
              </div>
              
              {/* Rating */}
              <div className="flex items-center space-x-3 mb-4">
                <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                  <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold text-sm">{tour.rating}</span>
                </div>
                <span className="text-gray-500 text-sm">({tour.review_count} รีวิว)</span>
                <div className="flex items-center text-green-600 text-xs">
                  <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="font-medium">รีวิวจริง</span>
                </div>
              </div>
              
              {/* Next Departure */}
              <div className="mb-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1 text-blue-500" />
                  <span>ช่วงเวลาเดินทาง: {tour.availability.departure_dates[0]?.date_range?.replace(/(\d+)\s+(ม\.ค\.|ก\.พ\.|มี\.ค\.|เม\.ย\.|พ\.ค\.|มิ\.ย\.|ก\.ค\.|ส\.ค\.|ก\.ย\.|ต\.ค\.|พ\.ย\.|ธ\.ค\.)/g, '$1 $2 68') || '28 ส.ค. 68 - 3 ก.ย. 68'}</span>
                </div>
                {tour.availability.available_seats <= 3 && (
                  <div className="text-orange-600 text-xs mt-1">
                    ⚡ เหลือที่นั่งน้อย ({tour.availability.available_seats} ที่)
                  </div>
                )}
              </div>
              
              {/* Price & CTA */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div>
                  {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                    <div className="text-sm text-gray-400 line-through">
                      ฿{formatPrice(tour.pricing.original_price)}
                    </div>
                  )}
                  <div className="text-2xl font-bold text-blue-600">
                    ฿{formatPrice(tour.pricing.base_price)}
                  </div>
                  <div className="text-xs text-gray-500">ต่อคน</div>
                  {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                    <div className="text-xs text-green-600 font-medium">
                      ประหยัด ฿{formatPrice(tour.pricing.original_price - tour.pricing.base_price)}
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onQuickBook?.(tour);
                    }}
                    className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 font-bold shadow-md px-4 py-2 rounded-lg text-sm flex items-center"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    จองด่วน
                  </button>
                  <Link href={tour.metadata.canonical_url}>
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center">
                      ดูรายละเอียด
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Prototype 2: Card with Side Progress Ring
const Prototype2: React.FC<CompactTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const { isExpanded, progress, elementRef, toggleExpand } = useAutoExpand();
  const formatPrice = (price: number) => price.toLocaleString('th-TH');
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0;

  return (
    <div ref={elementRef} className="relative mb-6">
      <div 
        className={`
          bg-white rounded-xl transition-all duration-500 
          ${isExpanded ? 'shadow-2xl ring-2 ring-blue-500/30' : 'shadow-md hover:shadow-lg'}
        `}
      >
        <div className="relative">
          {/* Compact Card */}
          <div 
            className={`
              transition-all duration-500 cursor-pointer
              ${isExpanded ? '' : 'hover:bg-gray-50/50'}
            `}
            onClick={toggleExpand}
          >
            <div className="flex p-3 md:p-4">
              {/* Progress Ring on Mobile / Desktop */}
              {progress > 0 && progress < 100 && (
                <div className="absolute right-2 top-2 md:right-3 md:top-3">
                  <svg className="w-10 h-10 -rotate-90">
                    <circle
                      cx="20"
                      cy="20"
                      r="18"
                      stroke="currentColor"
                      strokeWidth="2"
                      fill="none"
                      className="text-gray-200"
                    />
                    <circle
                      cx="20"
                      cy="20"
                      r="18"
                      stroke="currentColor"
                      strokeWidth="2"
                      fill="none"
                      strokeDasharray={`${2 * Math.PI * 18}`}
                      strokeDashoffset={`${2 * Math.PI * 18 * (1 - progress / 100)}`}
                      className="text-blue-500 transition-all duration-100"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs font-bold text-blue-600">{Math.round(progress)}%</span>
                  </div>
                </div>
              )}

              {/* Content Layout */}
              <div className="flex flex-col md:flex-row w-full gap-3 md:gap-4">
                {/* Image */}
                <div className="relative w-full md:w-40 h-28 md:h-32 rounded-lg overflow-hidden flex-shrink-0">
                  <Image
                    src={tour.media.hero_image}
                    alt={tour.title}
                    fill
                    className="object-cover"
                  />
                  {hasDiscount && (
                    <div className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full font-semibold">
                      ลด {tour.pricing.discount_percentage}%
                    </div>
                  )}
                  <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded backdrop-blur-sm">
                    {tour.duration_days}วัน{tour.nights}คืน
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1">
                  <h3 className="font-bold text-base md:text-lg mb-2 line-clamp-2">
                    {tour.title}
                  </h3>
                  
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex items-center bg-yellow-50 px-2 py-1 rounded">
                      <svg className="w-4 h-4 text-yellow-500 fill-current" viewBox="0 0 20 20">
                        <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                      </svg>
                      <span className="text-sm font-semibold ml-1">{tour.rating}</span>
                      <span className="text-xs text-gray-600 ml-1">({tour.review_count})</span>
                    </div>
                    
                    <div className="hidden md:flex flex-wrap gap-1">
                      {tour.highlights.slice(0, 2).map((h, i) => (
                        <span key={i} className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded">
                          {typeof h === 'string' ? h : h.text}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-end justify-between">
                    <div>
                      {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                        <span className="text-sm text-gray-400 line-through block">
                          ฿{formatPrice(tour.pricing.original_price)}
                        </span>
                      )}
                      <span className="text-xl md:text-2xl font-bold text-blue-600">
                        ฿{formatPrice(tour.pricing.base_price)}
                      </span>
                      <span className="text-xs text-gray-500 ml-1">/ คน</span>
                    </div>

                    <button
                      className={`
                        flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium text-sm transition-all
                        ${isExpanded 
                          ? 'bg-blue-100 text-blue-700' 
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }
                      `}
                    >
                      <span className="hidden md:inline">
                        {isExpanded ? 'ซ่อน' : 'ดูเพิ่ม'}
                      </span>
                      <svg 
                        className={`w-4 h-4 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Expanded Details */}
          {isExpanded && (
            <div className="border-t border-gray-100 p-3 md:p-4 animate-fadeIn">
              <p className="text-sm text-gray-600 mb-3 leading-relaxed">
                {tour.description}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                <div className="flex items-center text-sm">
                  <svg className="w-4 h-4 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="text-gray-700">{tour.location.city || tour.location.country}</span>
                </div>
                <div className="flex items-center text-sm">
                  <svg className="w-4 h-4 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span className="text-gray-700">{tour.availability.departure_dates[0]?.date || 'ทุกวัน'}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {tour.highlights.map((highlight, idx) => (
                  <span key={idx} className="bg-gradient-to-r from-blue-50 to-indigo-50 text-blue-700 text-xs px-3 py-1.5 rounded-full border border-blue-200">
                    {typeof highlight === 'string' ? highlight : highlight.text}
                  </span>
                ))}
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onQuickBook?.(tour);
                  }}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2.5 px-4 rounded-lg font-semibold hover:from-blue-600 hover:to-blue-700 transition-all shadow-md"
                >
                  <span className="flex items-center justify-center">
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    จองด่วน
                  </span>
                </button>
                <Link href={tour.metadata.canonical_url}>
                  <button className="px-6 py-2.5 border-2 border-blue-500 text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-all">
                    รายละเอียด
                  </button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Main Component Selector
interface CompactTourCardSelectorProps {
  tour: SearchIndexTour;
  prototype: 1 | 2 | 3 | 4 | 5;
  isWishlisted?: boolean;
  onWishlistToggle?: (tourId: string) => void;
  onQuickBook?: (tour: SearchIndexTour) => void;
}

const CompactTourCard: React.FC<CompactTourCardSelectorProps> = ({
  tour,
  prototype = 2,
  isWishlisted = false,
  onWishlistToggle,
  onQuickBook
}) => {
  const props = { tour, isWishlisted, onWishlistToggle, onQuickBook };

  switch (prototype) {
    case 1:
      return <Prototype1 {...props} />;
    case 2:
      return <Prototype2 {...props} />;
    case 3:
      return <Prototype2 {...props} />; // ใช้ Prototype2 แทน
    case 4:
      return <Prototype1 {...props} />; // ใช้ Prototype1 แทน
    case 5:
      return <Prototype2 {...props} />; // ใช้ Prototype2 แทน
    default:
      return <Prototype2 {...props} />;
  }
};

export default CompactTourCard;