'use client'

import React, { useState, useEffect } from 'react'
import {
  Search, Filter, X, MapPin, Calendar, Star, TrendingUp,
  ChevronDown, ArrowUp, MessageCircle, Phone, Sparkles,
  Users, Clock, Gift, Zap, Globe, Heart
} from 'lucide-react'

const TourSearch57 = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [countdown1, setCountdown1] = useState({
    hours: 2,
    minutes: 35,
    seconds: 41
  })
  const [countdown2, setCountdown2] = useState({
    hours: 1,
    minutes: 47,
    seconds: 23
  })

  // Auto-play carousel for Cards - Video plays first, then images
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % 5)
    }, 5000) // Change every 5 seconds (video gets more time)

    return () => clearInterval(interval)
  }, [])

  // Update carousel indicators and visibility
  useEffect(() => {
    // Handle Card 1 carousel
    const carouselItems1 = document.querySelectorAll('.carousel-item-1')

    carouselItems1.forEach((item, index) => {
      if (index === currentImageIndex) {
        item.classList.remove('opacity-0')
        item.classList.add('opacity-100')
      } else {
        item.classList.remove('opacity-100')
        item.classList.add('opacity-0')
      }
    })

    // Handle Card 2 carousel
    const carouselItems2 = document.querySelectorAll('.carousel-item-2')

    carouselItems2.forEach((item, index) => {
      if (index === currentImageIndex) {
        item.classList.remove('opacity-0')
        item.classList.add('opacity-100')
      } else {
        item.classList.remove('opacity-100')
        item.classList.add('opacity-0')
      }
    })
  }, [currentImageIndex])

  // Countdown timer for Flash Sale Card 1
  useEffect(() => {
    const timer1 = setInterval(() => {
      setCountdown1(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else {
          return { hours: 23, minutes: 59, seconds: 59 } // Reset to new day
        }
      })
    }, 1000)

    return () => clearInterval(timer1)
  }, [])

  // Countdown timer for Flash Sale Card 2
  useEffect(() => {
    const timer2 = setInterval(() => {
      setCountdown2(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else {
          return { hours: 23, minutes: 59, seconds: 59 } // Reset to new day
        }
      })
    }, 1000)

    return () => clearInterval(timer2)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <style jsx>{`
        @keyframes pulse-red {
          0%, 100% {
            box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.9), 0 0 20px rgba(239, 68, 68, 0.5);
          }
          50% {
            box-shadow: 0 0 0 15px rgba(220, 38, 38, 0), 0 0 30px rgba(239, 68, 68, 0.8);
          }
        }

        @keyframes countdown-breathe {
          0%, 100% {
            transform: scale(1);
            opacity: 0.9;
          }
          50% {
            transform: scale(1.02);
            opacity: 1;
          }
        }

        .flash-sale-card {
          animation: pulse-red 2s infinite;
        }

        .countdown-simple {
          background: rgba(255, 255, 255, 0.95);
          color: #dc2626;
          border: 1px solid rgba(220, 38, 38, 0.2);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
      `}</style>
      <main className="container mx-auto px-4 py-4">
        <div className="max-w-7xl mx-auto">
          {/* Header Section */}
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              ค้นหาทัวร์ที่ใช่สำหรับคุณ
            </h1>
            <p className="text-gray-600 mb-4">เลือกจากทัวร์ยอดนิยมที่คัดสรรมาเป็นพิเศษ</p>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

            {/* Card 1 - Flash Sale with Flight Info and Tour Code */}
            <div className="group cursor-pointer">
              <div className="relative aspect-[5/6] overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300 flash-sale-card">

                {/* Full Background Carousel */}
                <div className="absolute inset-0">
                  <div className="carousel-container-1 relative w-full h-full">
                    <video
                      src="/images/countries/japan-6.mov"
                      className="carousel-item-1 absolute inset-0 w-full h-full object-cover transition-opacity duration-500"
                      autoPlay
                      loop
                      muted
                      playsInline
                    />
                    <img
                      src="/images/countries/japan-1-1.jpg"
                      alt="Japan 1"
                      className="carousel-item-1 absolute inset-0 w-full h-full object-cover transition-opacity duration-500 opacity-0"
                    />
                    <img
                      src="/images/countries/japan-1-2.jpg"
                      alt="Japan 2"
                      className="carousel-item-1 absolute inset-0 w-full h-full object-cover transition-opacity duration-500 opacity-0"
                    />
                    <img
                      src="/images/countries/japan-1-3.jpg"
                      alt="Japan 3"
                      className="carousel-item-1 absolute inset-0 w-full h-full object-cover transition-opacity duration-500 opacity-0"
                    />
                    <img
                      src="/images/countries/japan-1-4.jpg"
                      alt="Japan 4"
                      className="carousel-item-1 absolute inset-0 w-full h-full object-cover transition-opacity duration-500 opacity-0"
                    />
                  </div>

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                </div>

                {/* Elegant Flight Info - Red Theme */}
                <div className="absolute top-3 left-3 z-20">
                  <div className="bg-gradient-to-r from-white/95 to-white/90 backdrop-blur-md rounded-xl shadow-xl overflow-hidden">
                    <div className="flex items-center">

                      {/* Airline Section */}
                      <div className="flex items-center gap-2 px-3 py-2 border-r border-red-100">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gradient-to-br from-red-400 to-rose-600 rounded-full blur-md opacity-70"></div>
                          <div className="relative bg-gradient-to-br from-red-500 to-rose-600 p-1.5 rounded-full">
                            <svg className="w-3 h-3 transform rotate-45 text-white" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/>
                            </svg>
                          </div>
                        </div>
                        <div>
                          <p className="text-[9px] text-gray-500 font-medium uppercase tracking-wider">Thai Airways</p>
                          <p className="text-xs font-bold text-gray-900 -mt-0.5">บินตรง</p>
                        </div>
                      </div>

                      {/* Date Section */}
                      <div className="px-3 py-2 bg-gradient-to-r from-red-50 to-rose-50">
                        <p className="text-[9px] text-blue-600 font-medium">ช่วงเดินทาง</p>
                        <p className="text-xs font-bold text-red-900 -mt-0.5">มี.ค. - พ.ค. 68</p>
                      </div>

                    </div>
                  </div>
                </div>

                {/* Tour Code - Separate Top Right */}
                <div className="absolute top-0 right-0 z-20">
                  <div className="bg-gradient-to-bl from-red-600 to-red-700 text-white px-3.5 py-2 rounded-bl-xl shadow-md">
                    <p className="text-xs font-semibold tracking-wide">TW61529</p>
                  </div>
                </div>

                {/* Main Content - Bottom Focus */}
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white z-10">

                  {/* Flash Sale Badge */}
                  <div className="mb-2">
                    <div className="bg-red-600 text-white px-3 py-1 rounded text-xs font-bold inline-block shadow-lg animate-bounce">
                      Flash Sale
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold mb-1 leading-tight drop-shadow-lg">
                    ทัวร์ญี่ปุ่น โอซาก้า โตเกียว 7 วัน 5 คืน
                  </h3>

                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3 text-sm">
                    <div className="flex text-yellow-400 text-sm">★★★★★</div>
                    <span className="text-sm">4.8 (124 รีวิว)</span>
                  </div>

                  {/* Highlight Text */}
                  <div className="mb-6 text-sm leading-relaxed">
                    <p className="drop-shadow-lg">สัมผัสความมหัศจรรย์ของญี่ปุ่น</p>
                    <p className="drop-shadow-lg">พร้อมประสบการณ์สุดพิเศษที่ไม่ลืม</p>
                  </div>

                  {/* Price Section */}
                  <div className="bg-gradient-to-r from-red-600/90 to-red-700/90 backdrop-blur-sm rounded-lg p-3 relative">
                    {/* Countdown Timer - Clean Design */}
                    <div className="absolute -top-5 left-0 bg-white text-red-600 px-3 py-1.5 rounded-r-lg rounded-tl-md text-sm font-bold shadow-md flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{String(countdown1.hours).padStart(2, '0')}:{String(countdown1.minutes).padStart(2, '0')}:{String(countdown1.seconds).padStart(2, '0')}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold">฿89,900</span>
                          <span className="text-sm line-through opacity-70">฿119,900</span>
                        </div>
                        <p className="text-xs opacity-90">ประหยัด ฿30,000 • ผ่อน ฿14,983/เดือน</p>
                      </div>
                      <button className="bg-white text-red-600 px-2 py-2 rounded-lg font-bold text-sm hover:scale-105 transition-all flex items-center gap-2 group">
                        <span>โปรโมชั่นพิเศษ</span>
                        <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8.59 16.59L13.17 12L8.59 7.41L10 6l6 6-6 6-1.41-1.41z"/>
                        </svg>
                      </button>
                    </div>
                  </div>

                </div>

                {/* Image Indicators - Right Side */}
                <div className="absolute top-1/2 right-4 transform -translate-y-1/2 flex flex-col space-y-2 z-20">
                  {[0, 1, 2, 3, 4].map((index) => (
                    <div
                      key={index}
                      className={`carousel-indicator-1 w-2 h-2 rounded-full transition-all duration-300 ${
                        index === currentImageIndex ? 'bg-red-500 shadow-lg' : 'bg-white/60'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Card 2 - Premium Tour with Flight Info and Tour Code */}
            <div className="group cursor-pointer">
              <div className="relative aspect-[5/6] overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300">

                {/* Single Background Image */}
                <div className="absolute inset-0">
                  <img
                    src="/images/countries/japan-2.jpg"
                    alt="Hokkaido"
                    className="absolute inset-0 w-full h-full object-cover object-center"
                    style={{
                      imageRendering: 'pixelated',
                      imageRendering: '-webkit-optimize-contrast',
                      imageRendering: '-moz-crisp-edges',
                      imageRendering: 'crisp-edges',
                      filter: 'contrast(1.3) saturate(1.2) brightness(1.05) blur(0px) sharpen(2px)',
                      transform: 'scale(1.002)',
                      WebkitBackfaceVisibility: 'hidden',
                      backfaceVisibility: 'hidden',
                      WebkitPerspective: 1000,
                      perspective: 1000,
                      willChange: 'transform'
                    }}
                  />

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                </div>

                {/* Elegant Flight Info - Blue Theme */}
                <div className="absolute top-3 left-3 z-20">
                  <div className="bg-gradient-to-r from-white/95 to-white/90 backdrop-blur-md rounded-xl shadow-xl overflow-hidden">
                    <div className="flex items-center">

                      {/* Airline Section */}
                      <div className="flex items-center gap-2 px-3 py-2 border-r border-blue-100">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full blur-md opacity-70"></div>
                          <div className="relative bg-gradient-to-br from-blue-500 to-blue-600 p-1.5 rounded-full">
                            <svg className="w-3 h-3 transform rotate-45 text-white" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/>
                            </svg>
                          </div>
                        </div>
                        <div>
                          <p className="text-[9px] text-gray-500 font-medium uppercase tracking-wider">Thai Airways</p>
                          <p className="text-xs font-bold text-gray-900 -mt-0.5">บินตรง</p>
                        </div>
                      </div>

                      {/* Date Section */}
                      <div className="px-3 py-2 bg-gradient-to-r from-blue-50 to-blue-50">
                        <p className="text-[9px] text-blue-600 font-medium">ช่วงเดินทาง</p>
                        <p className="text-xs font-bold text-blue-900 -mt-0.5">ก.ย. - พ.ย. 68</p>
                      </div>

                    </div>
                  </div>
                </div>

                {/* Tour Code - Separate Top Right */}
                <div className="absolute top-0 right-0 z-20">
                  <div className="bg-gradient-to-bl from-blue-600 to-blue-700 text-white px-3.5 py-2 rounded-bl-xl shadow-md">
                    <p className="text-xs font-semibold tracking-wide">TW62841</p>
                  </div>
                </div>

                {/* Main Content - Bottom Focus */}
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white z-10">

                  {/* Premium Badge */}
                  <div className="mb-2">
                    <div className="bg-blue-600 text-white px-3 py-1 rounded text-xs font-bold inline-block shadow-lg">
                      Premium Tour
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold mb-1 leading-tight drop-shadow-lg">
                    ทัวร์ญี่ปุ่น ฮอกไกโด 7 วัน 5 คืน
                  </h3>

                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3 text-sm">
                    <div className="flex text-yellow-400 text-sm">
                      <span>★★★</span>
                      <span style={{position: 'relative', display: 'inline-block'}}>
                        <span style={{color: '#d1d5db'}}>★</span>
                        <span style={{position: 'absolute', left: 0, top: 0, width: '50%', overflow: 'hidden', color: '#fbbf24'}}>★</span>
                      </span>
                      <span style={{color: '#d1d5db'}}>★</span>
                    </div>
                    <span className="text-sm">3.5 (89 รีวิว)</span>
                  </div>

                  {/* Highlight Text */}
                  <div className="mb-3 text-sm leading-relaxed">
                    <p className="drop-shadow-lg">สัมผัสความมหัศจรรย์ของฮอกไกโด</p>
                    <p className="drop-shadow-lg">พร้อมประสบการณ์สุดพิเศษที่ไม่ลืม</p>
                  </div>

                  {/* Price Section */}
                  <div className="bg-gradient-to-r from-blue-600/90 to-blue-700/90 backdrop-blur-sm rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold">฿78,900</span>
                          <span className="text-sm line-through opacity-70">฿98,900</span>
                        </div>
                        <p className="text-xs opacity-90">ประหยัด ฿20,000 • ผ่อน ฿13,150/เดือน</p>
                      </div>
                      <button className="bg-white text-blue-600 px-2 py-2 rounded-lg font-bold text-sm hover:scale-105 transition-all flex items-center gap-2 group">
                        <span>จองตอนนี้</span>
                        <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8.59 16.59L13.17 12L8.59 7.41L10 6l6 6-6 6-1.41-1.41z"/>
                        </svg>
                      </button>
                    </div>
                  </div>

                </div>

                {/* Image Indicators - Right Side */}
                <div className="absolute top-1/2 right-4 transform -translate-y-1/2 flex flex-col space-y-2 z-20">
                  {[0, 1, 2, 3, 4].map((index) => (
                    <div
                      key={index}
                      className={`carousel-indicator-2 w-2 h-2 rounded-full transition-all duration-300 ${
                        index === currentImageIndex ? 'bg-blue-500 shadow-lg' : 'bg-white/60'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Card 3 - Singapore Flash Sale */}
            <div className="group cursor-pointer">
              <div className="relative aspect-[5/6] overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300 flash-sale-card">

                {/* Single Background Image */}
                <div className="absolute inset-0">
                  <img
                    src="/images/countries/singapore.jpg"
                    alt="Singapore"
                    className="absolute inset-0 w-full h-full object-cover object-center"
                    style={{
                      imageRendering: 'pixelated',
                      imageRendering: '-webkit-optimize-contrast',
                      imageRendering: '-moz-crisp-edges',
                      imageRendering: 'crisp-edges',
                      filter: 'contrast(1.3) saturate(1.2) brightness(1.05) blur(0px) sharpen(2px)',
                      transform: 'scale(1.002)',
                      WebkitBackfaceVisibility: 'hidden',
                      backfaceVisibility: 'hidden',
                      WebkitPerspective: 1000,
                      perspective: 1000,
                      willChange: 'transform'
                    }}
                  />

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                </div>

                {/* Elegant Flight Info - Red Theme */}
                <div className="absolute top-3 left-3 z-20">
                  <div className="bg-gradient-to-r from-white/95 to-white/90 backdrop-blur-md rounded-xl shadow-xl overflow-hidden">
                    <div className="flex items-center">

                      {/* Airline Section */}
                      <div className="flex items-center gap-2 px-3 py-2 border-r border-red-100">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gradient-to-br from-red-400 to-rose-600 rounded-full blur-md opacity-70"></div>
                          <div className="relative bg-gradient-to-br from-red-500 to-rose-600 p-1.5 rounded-full">
                            <svg className="w-3 h-3 transform rotate-45 text-white" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/>
                            </svg>
                          </div>
                        </div>
                        <div>
                          <p className="text-[9px] text-gray-500 font-medium uppercase tracking-wider">Singapore Airlines</p>
                          <p className="text-xs text-gray-900 -mt-0.5">
                            <span className="font-bold">บินตรง</span>
                            <span className="text-gray-600 font-normal"> | บินเช้ากลับดึก</span>
                          </p>
                        </div>
                      </div>

                      {/* Date Section */}
                      <div className="px-3 py-2 bg-gradient-to-r from-red-50 to-rose-50">
                        <p className="text-[9px] text-blue-600 font-medium">ช่วงเดินทาง</p>
                        <p className="text-xs font-bold text-red-900 -mt-0.5">ธ.ค. - ก.พ. 68</p>
                      </div>

                    </div>
                  </div>
                </div>

                {/* Tour Code - Separate Top Right */}
                <div className="absolute top-0 right-0 z-20">
                  <div className="bg-gradient-to-bl from-red-600 to-red-700 text-white px-3.5 py-2 rounded-bl-xl shadow-md">
                    <p className="text-xs font-semibold tracking-wide">TW63254</p>
                  </div>
                </div>

                {/* Main Content - Bottom Focus */}
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white z-10">

                  {/* Flash Sale Badge */}
                  <div className="mb-2">
                    <div className="bg-red-600 text-white px-3 py-1 rounded text-xs font-bold inline-block shadow-lg animate-bounce">
                      Flash Sale
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold mb-1 leading-tight drop-shadow-lg">
                    ทัวร์สิงคโปร์ 4 วัน 3 คืน
                  </h3>

                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3 text-sm">
                    <div className="flex text-yellow-400 text-sm">★★★★★</div>
                    <span className="text-sm">4.6 (156 รีวิว)</span>
                  </div>

                  {/* Highlight Text */}
                  <div className="mb-6 text-sm leading-relaxed">
                    <p className="drop-shadow-lg">สัมผัสเสน่ห์เมืองสิงคโปร์</p>
                    <p className="drop-shadow-lg">ช้อปปิ้งและสถานที่ท่องเที่ยวระดับโลก</p>
                  </div>

                  {/* Price Section */}
                  <div className="bg-gradient-to-r from-red-600/90 to-red-700/90 backdrop-blur-sm rounded-lg p-3 relative">
                    {/* Countdown Timer - Clean Design */}
                    <div className="absolute -top-5 left-0 bg-white text-red-600 px-3 py-1.5 rounded-r-lg rounded-tl-md text-sm font-bold shadow-md flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{String(countdown2.hours).padStart(2, '0')}:{String(countdown2.minutes).padStart(2, '0')}:{String(countdown2.seconds).padStart(2, '0')}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold">฿32,900</span>
                          <span className="text-sm line-through opacity-70">฿45,900</span>
                        </div>
                        <p className="text-xs opacity-90">ประหยัด ฿13,000 • ผ่อน ฿5,483/เดือน</p>
                      </div>
                      <button className="bg-white text-red-600 px-2 py-2 rounded-lg font-bold text-sm hover:scale-105 transition-all flex items-center gap-2 group">
                        <span>โปรโมชั่นพิเศษ</span>
                        <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8.59 16.59L13.17 12L8.59 7.41L10 6l6 6-6 6-1.41-1.41z"/>
                        </svg>
                      </button>
                    </div>
                  </div>

                </div>

                {/* Image Indicators - Right Side */}
                <div className="absolute top-1/2 right-4 transform -translate-y-1/2 flex flex-col space-y-2 z-20">
                  <div className="w-2 h-2 bg-red-500 rounded-full shadow-lg"></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  )
}

export default TourSearch57