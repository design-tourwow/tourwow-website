'use client'

import React, { useState, useEffect } from 'react'
import {
  Search, Filter, X, MapPin, Calendar, Star, TrendingUp,
  ChevronDown, ArrowUp, MessageCircle, Phone, Sparkles,
  Users, Clock, Gift, Zap, Globe, Heart
} from 'lucide-react'

const TourSearch56 = () => {
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <>
      <style jsx>{`
        @keyframes bounce-x {
          0%, 100% {
            transform: translateX(0px);
          }
          50% {
            transform: translateX(4px);
          }
        }
        .animate-bounce-x {
          animation: bounce-x 1s ease-in-out infinite;
        }
        @keyframes gentle-bounce {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-3px);
          }
        }
        .animate-gentle-bounce {
          animation: gentle-bounce 1.5s ease-in-out infinite;
        }
        @keyframes pulse-glow {
          0%, 100% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
          }
          50% {
            transform: scale(1.05);
            box-shadow: 0 0 0 4px rgba(239, 68, 68, 0);
          }
        }
        .animate-pulse-glow {
          animation: pulse-glow 2s ease-in-out infinite;
        }
        @keyframes flash-gradient {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        .flash-gradient {
          background: linear-gradient(89deg, #fca5a5, #ef4444, #dc2626, #b91c1c, #ef4444, #f87171);
          background-size: 300% 300%;
          animation: flash-gradient 3s ease infinite;
        }
      `}</style>
    <div className="min-h-screen bg-gray-50">
      <main className="container mx-auto px-4 py-4">
        <div className="max-w-7xl mx-auto">
          {/* Header Section */}
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              ค้นหาทัวร์ที่ใช่สำหรับคุณ
            </h1>
            <p className="text-gray-600">
              เลือกจากทัวร์คุณภาพสูงกว่า 1,000+ โปรแกรม
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="ค้นหาจุดหมายปลายทาง, ประเทศ, หรือกิจกรรม..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Results Grid */}
          <div className="w-full py-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-4 md:gap-6">

              {/* Tour Card 1 */}
              <div className="group cursor-pointer">
                <div className="relative aspect-[5/6] overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300">
                  {/* Tour Code */}
                  <div className="absolute top-0 right-0 z-10">
                    <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white px-4 py-1.5 rounded-bl-xl shadow-md">
                      <p className="text-base font-semibold tracking-wide">TW29847</p>
                    </div>
                  </div>
                  <video
                    src="/images/countries/japan-6.mov"
                    className="w-full h-full object-cover group-hover:scale-110 transition-all duration-500"
                    autoPlay
                    loop
                    muted
                    playsInline
                  />

                  {/* Modern Minimal Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>

                  {/* Minimal Content */}
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20">
                      {/* Location */}
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-white text-sm font-medium">Osaka, Japan</span>
                      </div>

                      {/* Title */}
                      <h3 className="text-white text-lg font-bold mb-3 line-clamp-2">
                        Premium Japan Experience
                      </h3>

                      {/* Price */}
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-white text-2xl font-bold">฿89,900</span>
                          <span className="text-white/60 text-sm ml-2 line-through">฿119,900</span>
                        </div>
                        <div className="bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                          <span className="text-white text-xs font-medium">7 Days</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tour Card 2 - Modern Minimal Style */}
              <div className="group cursor-pointer">
                <div className="relative aspect-[5/6] overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300">
                  {/* Tour Code */}
                  <div className="absolute top-0 right-0 z-10">
                    <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white px-4 py-1.5 rounded-bl-xl shadow-md">
                      <p className="text-base font-semibold tracking-wide">TW73512</p>
                    </div>
                  </div>
                  <video
                    src="/images/countries/japan-6.mov"
                    className="w-full h-full object-cover group-hover:scale-110 transition-all duration-500"
                    autoPlay
                    loop
                    muted
                    playsInline
                  />

                  {/* Modern Minimal Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>

                  {/* Minimal Content */}
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="bg-white/15 backdrop-blur-md rounded-2xl p-4 border border-white/30">
                      {/* Flash Badge */}
                      <div className="flex items-center gap-2 mb-3">
                        <div className="bg-red-500/90 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M13 10V3L4 14h7v7l9-11h-7z" clipRule="evenodd" />
                          </svg>
                          Flash Sale
                        </div>
                        <span className="text-white/80 text-sm">USJ Special</span>
                      </div>

                      {/* Title */}
                      <h3 className="text-white text-lg font-bold mb-3 line-clamp-2">
                        Universal Studios Japan Adventure
                      </h3>

                      {/* Price & Details */}
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-white text-2xl font-bold">฿89,900</span>
                          <span className="text-white/60 text-sm ml-2 line-through">฿119,900</span>
                        </div>
                        <div className="flex gap-2">
                          <div className="bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                            <span className="text-white text-xs font-medium">7D5N</span>
                          </div>
                          <div className="bg-red-500/20 backdrop-blur-sm rounded-full px-3 py-1 border border-red-300/30">
                            <span className="text-white text-xs font-medium">3 วันสุดท้าย</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tour Card 3 - Modern Minimal Style */}
              <div className="group cursor-pointer">
                <div className="relative aspect-[5/6] overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300">
                  {/* Tour Code */}
                  <div className="absolute top-0 right-0 z-10">
                    <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white px-4 py-1.5 rounded-bl-xl shadow-md">
                      <p className="text-base font-semibold tracking-wide">TW68324</p>
                    </div>
                  </div>
                  <video
                    src="/images/countries/japan-6.mov"
                    className="w-full h-full object-cover group-hover:scale-110 transition-all duration-500"
                    autoPlay
                    loop
                    muted
                    playsInline
                  />

                  {/* Modern Minimal Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>

                  {/* Minimal Content */}
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="bg-white/12 backdrop-blur-md rounded-2xl p-4 border border-white/25">
                      {/* Premium Badge */}
                      <div className="flex items-center gap-2 mb-3">
                        <div className="bg-gradient-to-r from-purple-500/80 to-blue-500/80 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" clipRule="evenodd" />
                          </svg>
                          Premium
                        </div>
                        <span className="text-white/80 text-sm">Cherry Blossom</span>
                      </div>

                      {/* Title */}
                      <h3 className="text-white text-lg font-bold mb-3 line-clamp-2">
                        Sakura Season Collection
                      </h3>

                      {/* Price & Features */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-white text-2xl font-bold">฿89,900</span>
                            <span className="text-white/60 text-sm ml-2 line-through">฿119,900</span>
                          </div>
                          <div className="bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                            <span className="text-white text-xs font-medium">Premium</span>
                          </div>
                        </div>

                        {/* Features */}
                        <div className="flex items-center gap-3 text-xs">
                          <div className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></div>
                            <span className="text-white/90">ไม่มีวันอิสระ</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-amber-400 rounded-full"></div>
                            <span className="text-white/90">ผ่อน 0%</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-rose-400 rounded-full"></div>
                            <span className="text-white/90">มื้อพิเศษ</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tour Card 4 - Modern Minimal Style */}
              <div className="group cursor-pointer">
                <div className="relative aspect-[5/6] overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300">
                  {/* Tour Code */}
                  <div className="absolute top-0 right-0 z-10">
                    <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white px-4 py-1.5 rounded-bl-xl shadow-md">
                      <p className="text-base font-semibold tracking-wide">TW49731</p>
                    </div>
                  </div>
                  <video
                    src="/images/countries/japan-6.mov"
                    className="w-full h-full object-cover group-hover:scale-110 transition-all duration-500"
                    autoPlay
                    loop
                    muted
                    playsInline
                  />

                  {/* Modern Minimal Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-transparent"></div>

                  {/* Minimal Content */}
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="bg-white/18 backdrop-blur-md rounded-2xl p-4 border border-white/35">
                      {/* Exclusive Badge */}
                      <div className="flex items-center gap-2 mb-3">
                        <div className="bg-gradient-to-r from-orange-500/80 to-red-500/80 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M9.664 1.319a.75.75 0 01.672 0 41.059 41.059 0 018.198 5.424.75.75 0 01-.254 1.285 31.372 31.372 0 00-7.86 3.83.75.75 0 01-.84 0 31.508 31.508 0 00-2.08-1.287V9.394c0-.244.116-.463.302-.592a35.504 35.504 0 013.305-2.033.75.75 0 00-.714-1.319 37 37 0 00-3.446 2.12A2.216 2.216 0 006 9.393v.38a31.293 31.293 0 00-4.28-1.746.75.75 0 01-.254-1.285 41.059 41.059 0 018.198-5.424zM6 11.459a29.848 29.848 0 00-2.455-1.158 41.029 41.029 0 00-.39 3.114.75.75 0 00.419.74c.528.256 1.046.53 1.554.82-.21-.899-.185-1.79.872-3.516zm8 0c1.059 1.727 1.082 2.617.872 3.516.508-.29 1.026-.564 1.554-.82a.75.75 0 00.419-.74 41.029 41.029 0 00-.39-3.114A29.848 29.848 0 0014 11.459z" clipRule="evenodd" />
                          </svg>
                          Exclusive
                        </div>
                        <span className="text-white/80 text-sm">Limited Edition</span>
                      </div>

                      {/* Title */}
                      <h3 className="text-white text-lg font-bold mb-3 line-clamp-2">
                        VIP Cultural Immersion
                      </h3>

                      {/* Price & Details */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-white text-2xl font-bold">฿89,900</span>
                            <span className="text-white/60 text-sm ml-2 line-through">฿119,900</span>
                          </div>
                          <div className="bg-gradient-to-r from-orange-500/20 to-red-500/20 backdrop-blur-sm rounded-full px-3 py-1 border border-orange-300/30">
                            <span className="text-white text-xs font-medium">VIP</span>
                          </div>
                        </div>

                        {/* Exclusive Features */}
                        <div className="flex items-center gap-2 text-xs">
                          <div className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full animate-pulse"></div>
                            <span className="text-white/90">Private Guide</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                            <span className="text-white/90">Michelin</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                            <span className="text-white/90">Ryokan</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </main>
    </div>
    </>
  )
}

export default TourSearch56