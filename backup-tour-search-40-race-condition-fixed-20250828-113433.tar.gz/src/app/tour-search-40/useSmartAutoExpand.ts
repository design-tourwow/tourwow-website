'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useCardExpansion } from './CardExpansionContext';

interface SmartAutoExpandOptions {
  threshold: number; // Time in ms before auto-expand
  viewportThreshold: number; // Percentage of card visible for activation
  stopScrollThreshold: number; // Time in ms user must stop scrolling
  enabled: boolean;
}

export const useSmartAutoExpand = (
  cardId: string, 
  options: Partial<SmartAutoExpandOptions> = {}
) => {
  const {
    threshold = 6000,
    viewportThreshold = 0.6,
    stopScrollThreshold = 1000,
    enabled = true
  } = options;

  const [isExpanded, setIsExpanded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isInViewport, setIsInViewport] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  
  const elementRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<NodeJS.Timeout>();
  const scrollStopRef = useRef<NodeJS.Timeout>();
  const lastScrollTime = useRef<number>(0);
  
  const { requestExpansion, releaseExpansion } = useCardExpansion();

  // Intersection Observer for viewport detection
  useEffect(() => {
    if (!enabled || !elementRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const isVisible = entry.intersectionRatio >= viewportThreshold;
          setIsInViewport(isVisible);
          
          if (isVisible) {
            // Card is in viewport, but wait for scroll to stop
            lastScrollTime.current = Date.now();
            
            if (scrollStopRef.current) {
              clearTimeout(scrollStopRef.current);
            }
            
            scrollStopRef.current = setTimeout(() => {
              // User stopped scrolling and card is in viewport
              if (requestExpansion(cardId)) {
                setIsFocused(true);
                startProgressAnimation();
              }
            }, stopScrollThreshold);
            
          } else {
            // Card is out of viewport, stop everything
            setIsFocused(false);
            releaseExpansion(cardId);
            stopProgressAnimation();
          }
        });
      },
      { 
        threshold: [viewportThreshold],
        rootMargin: '0px 0px -10% 0px' // Slight offset to ensure card is well in view
      }
    );

    observer.observe(elementRef.current);

    return () => {
      observer.disconnect();
      if (scrollStopRef.current) clearTimeout(scrollStopRef.current);
      if (progressRef.current) clearTimeout(progressRef.current);
      releaseExpansion(cardId);
    };
  }, [enabled, viewportThreshold, stopScrollThreshold, cardId, requestExpansion, releaseExpansion]);

  // Progress animation
  const startProgressAnimation = useCallback(() => {
    if (progressRef.current) return; // Already running
    
    const startTime = Date.now();
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progressPercent = Math.min((elapsed / threshold) * 100, 100);
      
      setProgress(progressPercent);
      
      if (progressPercent < 100 && isFocused) {
        progressRef.current = setTimeout(animate, 16); // ~60fps
      } else if (progressPercent >= 100) {
        setIsExpanded(true);
        setProgress(100);
      }
    };
    
    animate();
  }, [threshold, isFocused]);

  const stopProgressAnimation = useCallback(() => {
    if (progressRef.current) {
      clearTimeout(progressRef.current);
      progressRef.current = undefined;
    }
    setProgress(0);
  }, []);

  // Manual toggle function
  const toggleExpand = useCallback(() => {
    // Stop any auto-expansion process
    stopProgressAnimation();
    if (scrollStopRef.current) clearTimeout(scrollStopRef.current);
    
    const newExpanded = !isExpanded;
    
    if (newExpanded) {
      // Request permission to expand
      if (requestExpansion(cardId)) {
        setIsExpanded(true);
        setProgress(100);
      }
    } else {
      // Release and collapse
      releaseExpansion(cardId);
      setIsExpanded(false);
      setProgress(0);
    }
  }, [isExpanded, cardId, requestExpansion, releaseExpansion, stopProgressAnimation]);

  // Cleanup on component unmount
  useEffect(() => {
    return () => {
      stopProgressAnimation();
      releaseExpansion(cardId);
    };
  }, [cardId, releaseExpansion, stopProgressAnimation]);

  return {
    isExpanded,
    progress,
    isInViewport,
    isFocused,
    elementRef,
    toggleExpand,
    setIsExpanded
  };
};