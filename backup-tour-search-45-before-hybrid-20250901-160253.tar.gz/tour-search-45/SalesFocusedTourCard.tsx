'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { SearchIndexTour } from './types';
import { 
  Clock, MapPin, Star, Users, Heart, Shield, Check,
  Calendar, TrendingUp, Award, Sparkles, Plane
} from 'lucide-react';

interface SalesFocusedTourCardProps {
  tour: SearchIndexTour;
  isWishlisted?: boolean;
  onWishlistToggle?: (tourId: string) => void;
  onQuickBook?: (tour: SearchIndexTour) => void;
}

const SalesFocusedTourCard: React.FC<SalesFocusedTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const [imageError, setImageError] = useState(false);
  
  const formatPrice = (price: number) => price.toLocaleString('th-TH');
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0;
  const savings = tour.pricing.original_price - tour.pricing.base_price;
  const savingsPercent = Math.round((savings / tour.pricing.original_price) * 100);

  // Mock airline data based on country
  const getAirlineInfo = (country: string) => {
    const airlines: { [key: string]: string } = {
      'ญี่ปุ่น': 'Thai Airways',
      'เกาหลีใต้': 'Korean Air',
      'ไต้หวัน': 'EVA Air',
      'ยุโรป': 'Emirates',
      'จีน': 'China Airlines',
      'สิงคโปร์': 'Singapore Airlines',
      'มาเลเซีย': 'Malaysia Airlines',
      'ฮ่องกง': 'Cathay Pacific'
    };
    return airlines[country] || 'Premium Airlines';
  };

  // Calculate urgency factors
  const remainingSeats = Math.floor(Math.random() * 5) + 2; // Mock data: 2-6 seats
  const viewingNow = Math.floor(Math.random() * 10) + 3; // Mock data: 3-12 people

  return (
    <div className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-gray-100 relative max-w-7xl mx-auto">
      {/* Premium Badge */}
      {tour.quality.rating >= 4.5 && (
        <div className="absolute top-4 left-4 z-20 bg-gradient-to-r from-amber-500 to-yellow-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
          <Award className="w-3 h-3" />
          ทัวร์ยอดนิยม
        </div>
      )}

      {/* Main Container - Horizontal on desktop, vertical on mobile */}
      <div className="flex flex-col md:flex-row">
        {/* Image Section - Increased size for beautiful destination views */}
        <div className="relative w-full md:w-[480px] h-[280px] md:h-[360px] flex-shrink-0 overflow-hidden">
          <Image
            src={imageError ? '/images/tour-placeholder.jpg' : tour.media.hero_image}
            alt={tour.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-500"
            sizes="(max-width: 768px) 100vw, 480px"
            onError={() => setImageError(true)}
            priority
          />
          
          {/* Discount Overlay */}
          {hasDiscount && (
            <div className="absolute top-4 right-4 bg-red-500 text-white rounded-xl px-3 py-2 shadow-lg">
              <div className="text-2xl font-bold">-{savingsPercent}%</div>
              <div className="text-xs">ประหยัด</div>
            </div>
          )}

          {/* Wishlist Button */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onWishlistToggle?.(tour.metadata.id);
            }}
            className="absolute bottom-4 right-4 bg-white/95 backdrop-blur rounded-full p-2.5 shadow-lg hover:scale-110 transition-transform"
            aria-label={isWishlisted ? 'ลบจากรายการโปรด' : 'เพิ่มในรายการโปรด'}
          >
            <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
          </button>

          {/* Duration Badge */}
          <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur text-white px-3 py-1.5 rounded-lg text-sm font-medium">
            {tour.duration_days} วัน {tour.nights} คืน
          </div>
        </div>

        {/* Content Section */}
        <div className="flex-1 p-5 md:p-6 flex flex-col">
          {/* Title & Location */}
          <div className="mb-3">
            <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
              {tour.title}
            </h3>
            
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <div className="flex items-center text-gray-600">
                <MapPin className="w-4 h-4 mr-1" />
                <span className="font-medium">{tour.location.country}</span>
              </div>
              
              <div className="flex items-center text-gray-600">
                <Plane className="w-4 h-4 mr-1" />
                <span>{getAirlineInfo(tour.location.country)}</span>
              </div>

              {/* Rating */}
              <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
                <span className="font-bold text-sm">{tour.quality.rating}</span>
                <span className="text-gray-500 text-xs ml-1">({tour.quality.review_count})</span>
              </div>
            </div>
          </div>

          {/* Key Highlights - Sales focused */}
          <div className="flex-1 mb-4">
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="flex items-center text-sm text-gray-700">
                <Check className="w-4 h-4 mr-1.5 text-green-500 flex-shrink-0" />
                <span>บินตรง ไม่ต้องต่อเครื่อง</span>
              </div>
              <div className="flex items-center text-sm text-gray-700">
                <Check className="w-4 h-4 mr-1.5 text-green-500 flex-shrink-0" />
                <span>โรงแรม 4-5 ดาว</span>
              </div>
              <div className="flex items-center text-sm text-gray-700">
                <Check className="w-4 h-4 mr-1.5 text-green-500 flex-shrink-0" />
                <span>อาหารครบทุกมื้อ</span>
              </div>
              <div className="flex items-center text-sm text-gray-700">
                <Check className="w-4 h-4 mr-1.5 text-green-500 flex-shrink-0" />
                <span>ไกด์ไทย + ท้องถิ่น</span>
              </div>
            </div>

            {/* Trust Badges */}
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center text-blue-600 bg-blue-50 px-2 py-1 rounded">
                <Shield className="w-3 h-3 mr-1" />
                <span className="font-medium">การันตีคืนเงิน</span>
              </div>
              <div className="flex items-center text-green-600 bg-green-50 px-2 py-1 rounded">
                <Check className="w-3 h-3 mr-1" />
                <span className="font-medium">จ่ายเงินปลอดภัย</span>
              </div>
            </div>
          </div>

          {/* Urgency Indicators */}
          <div className="flex flex-wrap items-center gap-3 mb-4 text-sm">
            <div className="flex items-center text-orange-600 font-medium">
              <TrendingUp className="w-4 h-4 mr-1 animate-pulse" />
              <span>เหลือ {remainingSeats} ที่นั่ง</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Users className="w-4 h-4 mr-1" />
              <span>{viewingNow} คนกำลังดู</span>
            </div>
          </div>

          {/* Price & CTA Section */}
          <div className="border-t pt-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              {/* Original Price */}
              {tour.pricing.original_price > tour.pricing.base_price && (
                <div className="text-gray-400 text-sm line-through">
                  ฿{formatPrice(tour.pricing.original_price)}
                </div>
              )}
              
              {/* Current Price */}
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-blue-600">
                  ฿{formatPrice(tour.pricing.base_price)}
                </span>
                <span className="text-sm text-gray-500">ต่อคน</span>
              </div>
              
              {/* Savings */}
              {savings > 0 && (
                <div className="flex items-center gap-2 mt-1">
                  <Sparkles className="w-4 h-4 text-green-500" />
                  <span className="text-green-600 font-medium text-sm">
                    ประหยัด ฿{formatPrice(savings)}
                  </span>
                </div>
              )}
            </div>

            {/* CTA Buttons */}
            <div className="flex gap-2 w-full md:w-auto">
              <button 
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onQuickBook?.(tour);
                }}
                className="flex-1 md:flex-initial bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                จองด่วน
              </button>
              
              <Link href={tour.metadata.canonical_url} className="flex-1 md:flex-initial">
                <button className="w-full px-6 py-3 border-2 border-blue-500 text-blue-600 rounded-xl font-bold text-sm hover:bg-blue-50 transition-all duration-200">
                  ดูรายละเอียด
                </button>
              </Link>
            </div>
          </div>

          {/* Flash Sale Timer (if applicable) */}
          {hasDiscount && (
            <div className="mt-3 bg-red-50 border border-red-200 rounded-lg px-3 py-2 flex items-center justify-center gap-2">
              <span className="text-red-600 text-xs font-medium">🔥 โปรโมชั่นพิเศษหมดเวลาใน:</span>
              <span className="text-red-700 font-bold text-sm">23:45:30</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SalesFocusedTourCard;