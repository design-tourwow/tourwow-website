'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import './animations.css';
import Image from 'next/image';
import Link from 'next/link';
import { SearchIndexTour } from './types';
import { 
  Clock, MapPin, Star, Users, Heart, Zap, ChevronDown, 
  Calendar, ArrowRight
} from 'lucide-react';

// Utility hook for auto-expand with progress
const useAutoExpand = (threshold = 6000, enabled = true) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isInView, setIsInView] = useState(false);
  const timerRef = useRef<NodeJS.Timeout>();
  const progressRef = useRef<NodeJS.Timeout>();
  const elementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!enabled || !elementRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
            setIsInView(true);
            
            // Start smooth progress animation using requestAnimationFrame
            const startTime = Date.now();
            
            const animateProgress = () => {
              const elapsed = Date.now() - startTime;
              const progressPercent = Math.min((elapsed / threshold) * 100, 100);
              
              setProgress(progressPercent);
              
              if (progressPercent < 100) {
                progressRef.current = requestAnimationFrame(animateProgress);
              }
            };
            
            progressRef.current = requestAnimationFrame(animateProgress);

            // Auto expand after threshold
            timerRef.current = setTimeout(() => {
              setIsExpanded(true);
              setProgress(100);
            }, threshold);
          } else {
            setIsInView(false);
            setProgress(0);
            
            // Clear timers
            if (timerRef.current) clearTimeout(timerRef.current);
            if (progressRef.current) cancelAnimationFrame(progressRef.current);
          }
        });
      },
      { threshold: 0.5 }
    );

    observer.observe(elementRef.current);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressRef.current) cancelAnimationFrame(progressRef.current);
      observer.disconnect();
    };
  }, [threshold, enabled]);

  const toggleExpand = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    if (progressRef.current) cancelAnimationFrame(progressRef.current);
    
    // Add a small delay to ensure smooth transition
    setTimeout(() => {
      setIsExpanded(!isExpanded);
      setProgress(0);
    }, 50);
  }, [isExpanded]);

  return { isExpanded, progress, isInView, elementRef, toggleExpand, setIsExpanded };
};

interface CompactTourCardProps {
  tour: SearchIndexTour;
  prototype?: 1 | 2 | 3 | 4 | 5;
  isWishlisted?: boolean;
  onWishlistToggle?: (tourId: string) => void;
  onQuickBook?: (tour: SearchIndexTour) => void;
}

// Prototype 3: Enhanced Compact Card with Smooth Morphing
const Prototype3: React.FC<CompactTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const { isExpanded, progress, elementRef, toggleExpand } = useAutoExpand(6000);
  const formatPrice = (price: number) => price.toLocaleString('th-TH');
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0;
  const [isTransitioning, setIsTransitioning] = useState(false);
  const compactRef = useRef<HTMLDivElement>(null);
  const expandedRef = useRef<HTMLDivElement>(null);

  // Handle smooth morphing transition
  useEffect(() => {
    if (isExpanded !== undefined) {
      setIsTransitioning(true);
      const timer = setTimeout(() => {
        setIsTransitioning(false);
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [isExpanded]);

  // Mock data for airline and travel period since it's not in tour object
  const getAirlineInfo = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'Thai Airways (TG)';
      case 'เกาหลีใต้': return 'Korean Air (KE)';
      case 'ไต้หวัน': return 'EVA Air (BR)';
      case 'ยุโรป': return 'Emirates (EK)';
      case 'จีน': return 'China Airlines (CI)';
      case 'สิงคโปร์': return 'Singapore Airlines (SQ)';
      case 'มาเลเซีย': return 'Malaysia Airlines (MH)';
      case 'ฮ่องกง': return 'Cathay Pacific (CX)';
      default: return 'Thai Airways (TG)';
    }
  };

  const getTravelPeriod = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'ก.ย. 68 – เม.ย. 69';
      case 'เกาหลีใต้': return 'ต.ค. 68 – มี.ค. 69';
      case 'ไต้หวัน': return 'ก.ย. 68 – ก.พ. 69';
      case 'ยุโรป': return 'เม.ย. 68 – ต.ค. 68';
      case 'จีน': return 'ตลอดปี';
      case 'สิงคโปร์': return 'ตลอดปี';
      case 'มาเลเซีย': return 'ตลอดปี';
      case 'ฮ่องกง': return 'ต.ค. 68 – เม.ย. 69';
      default: return 'ก.ย. 68 – ก.พ. 69';
    }
  };

  return (
    <div ref={elementRef} className="relative mb-4 sm:mb-6">
      {/* Clean Loading Indicator - Best Practice */}
      {progress > 0 && progress < 100 && !isExpanded && (
        <>
          {/* Progress Bar Only */}
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gray-100 rounded-t-2xl z-10 pointer-events-none overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-t-2xl"
              style={{
                width: `${progress}%`,
                transition: 'width 100ms ease-out',
                willChange: 'width'
              }}
            />
          </div>
        </>
      )}

      <div 
        className={`
          bg-white rounded-xl border overflow-hidden
          ${isExpanded ? 'shadow-2xl border-blue-500/50' : 'shadow-md border-gray-200 hover:shadow-lg'}
          ${progress > 0 && progress < 100 && !isExpanded ? 'ring-1 ring-blue-500/10' : ''}
          transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]
        `}
      >
        {/* Enhanced Compact View with Smooth Height Transition */}
        <div 
          ref={compactRef}
          className="cursor-pointer group transition-colors duration-200 hover:bg-gray-50/50"
          onClick={toggleExpand}
          style={{
            maxHeight: isExpanded ? '0px' : '500px',
            opacity: isExpanded ? 0 : 1,
            transition: `max-height 0.5s cubic-bezier(0.4,0,0.2,1), opacity ${isExpanded ? '0.2s' : '0.4s 0.2s'} ease-out`,
            overflow: 'hidden',
            pointerEvents: isExpanded ? 'none' : 'auto'
          }}
        >
          <div className="flex p-3 md:p-4">
            {/* Main Image */}
            <div className="relative w-20 sm:w-24 md:w-32 lg:w-40 h-16 sm:h-20 md:h-24 lg:h-28 flex-shrink-0 rounded-lg overflow-hidden">
              <Image
                src={tour.media.hero_image}
                alt={tour.title}
                fill
                className="object-cover"
              />
              {hasDiscount && (
                <span className="absolute top-1 left-1 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full font-semibold">
                  -{tour.pricing.discount_percentage}%
                </span>
              )}
              {/* Duration overlay */}
              <div className="absolute bottom-1 left-1 bg-black/70 text-white text-xs px-2 py-1 rounded backdrop-blur-sm">
                {tour.duration_days}วัน{tour.nights}คืน
              </div>
            </div>

            {/* Enhanced Info Section */}
            <div className="flex-1 ml-2 sm:ml-3 md:ml-4 flex flex-col justify-between min-w-0">
              {/* Top Section - Location & Title */}
              <div>
                <div className="flex items-center gap-1 sm:gap-2 mb-1">
                  <span className="text-xs sm:text-sm font-bold text-gray-800 truncate">{tour.location.country}</span>
                  <span className="text-gray-400 text-xs">•</span>
                  <span className="text-xs sm:text-sm text-gray-600 truncate">{tour.location.cities?.[0] || tour.location.country}</span>
                </div>
                <h3 className="font-medium text-xs sm:text-sm line-clamp-2 sm:line-clamp-1 text-gray-900 mb-1 sm:mb-2 leading-tight">
                  {tour.title}
                </h3>
              </div>

              {/* Middle Section - Details */}
              <div className="space-y-1 sm:space-y-2 mb-1 sm:mb-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center text-gray-600 min-w-0 flex-1 mr-2">
                    <svg className="w-3 h-3 mr-1 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                    <span className="truncate text-xs">{getAirlineInfo(tour.location.country)}</span>
                  </div>
                  <span className="text-blue-600 font-semibold text-xs sm:text-sm flex-shrink-0">
                    ฿{formatPrice(tour.pricing.base_price)}
                  </span>
                </div>
                <div className="flex items-center text-xs text-gray-600">
                  <svg className="w-3 h-3 mr-1 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span className="truncate">{getTravelPeriod(tour.location.country)}</span>
                </div>
              </div>

              {/* Bottom Section - Expand Button */}
              <div className="flex items-center justify-between">
                <div className="flex items-center text-xs text-gray-500">
                  <svg className="w-3 h-3 text-yellow-400 fill-current mr-1" viewBox="0 0 20 20">
                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                  </svg>
                  {tour.quality.rating} ({tour.quality.review_count})
                </div>
                
                <button
                  className={`
                    flex items-center gap-1 px-2 py-1 rounded-lg transition-all duration-300
                    ${isExpanded ? 'rotate-180 bg-blue-100 text-blue-600' : 'text-blue-600 bg-blue-50 group-hover:bg-blue-100'}
                  `}
                  aria-label={isExpanded ? 'ซ่อนรายละเอียด' : 'ดูรายละเอียด'}
                >
                  <span className="text-[10px] font-medium hidden sm:inline">ดูเพิ่ม</span>
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Expanded Content */}
        <div 
          className={`
            transition-all duration-400 ease-out border-t border-gray-100
            ${isExpanded 
              ? 'opacity-100 max-h-screen transform translate-y-0' 
              : 'opacity-0 max-h-0 overflow-hidden transform -translate-y-2'
            }
          `}
          style={{
            transitionDelay: isExpanded ? '150ms' : '0ms'
          }}
        >
          {/* Image Section */}
          <div className="relative h-48 md:h-52">
            <Image
              src={tour.media.hero_image}
              alt={tour.title}
              fill
              className="object-cover"
              sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
            />
            
            {/* Overlays */}
            <div className="absolute top-3 left-3 right-3 flex justify-between items-start">
              {hasDiscount && (
                <span className="bg-red-100 text-red-600 text-sm px-3 py-1 rounded-full font-bold">
                  ลด {tour.pricing.discount_percentage}%
                </span>
              )}
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onWishlistToggle?.(tour.metadata.id);
                }}
                className="bg-white/90 backdrop-blur-sm rounded-full p-2"
                aria-label={isWishlisted ? 'ลบจากรายการโปรด' : 'เพิ่มในรายการโปรด'}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
              </button>
            </div>
            
            {/* Duration Badge */}
            <div className="absolute bottom-3 left-3">
              <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-sm font-medium flex items-center">
                <Clock className="w-4 h-4 mr-1 text-blue-600" />
                {tour.duration_days}วัน{tour.nights}คืน
              </div>
            </div>
          </div>
          
          {/* Content Section */}
          <div className="p-4">
            {/* Title */}
            <h3 className="font-semibold text-gray-900 text-base mb-2 line-clamp-2 leading-tight">
              {tour.title}
            </h3>
            
            {/* Enhanced Location Info */}
            <div className="flex items-center gap-2 mb-3 text-sm">
              <div className="flex items-center text-gray-600">
                <MapPin className="w-4 h-4 mr-1 flex-shrink-0" />
                <span className="font-medium">{tour.location.country}</span>
              </div>
              {tour.location.cities && tour.location.cities.length > 0 && (
                <span className="text-gray-600">
                  {tour.location.cities.slice(0, 5).join(', ')}
                </span>
              )}
            </div>
            
            {/* Highlights */}
            <div className="flex flex-wrap gap-2 mb-3">
              {tour.highlights.slice(0, 3).map((highlight, idx) => (
                <span key={idx} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-lg">
                  {typeof highlight === 'string' ? highlight : highlight.text}
                </span>
              ))}
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-3 mb-4">
              <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold text-sm">{tour.quality.rating}</span>
              </div>
              <span className="text-gray-500 text-sm">({tour.quality.review_count} รีวิว)</span>
              <div className="flex items-center text-green-600 text-xs">
                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="font-medium">รีวิวจริง</span>
              </div>
            </div>

            {/* Enhanced information for Prototype 3 */}
            <div className="bg-gray-50 rounded-lg p-3 mb-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">สายการบิน:</span>
                  <div className="font-medium">{getAirlineInfo(tour.location.country)}</div>
                </div>
                <div>
                  <span className="text-gray-600">ช่วงเวลาเดินทาง:</span>
                  <div className="font-medium">{getTravelPeriod(tour.location.country)}</div>
                </div>
              </div>
            </div>

            {/* Price & CTA */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div>
                {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                  <span className="text-sm text-gray-400 line-through mr-2">
                    ฿{formatPrice(tour.pricing.original_price)}
                  </span>
                )}
                <span className="text-2xl font-bold text-blue-600">
                  ฿{formatPrice(tour.pricing.base_price)}
                </span>
                <div className="text-xs text-gray-500">ต่อคน</div>
                {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                  <div className="text-xs text-green-600 font-medium">
                    ประหยัด ฿{formatPrice(tour.pricing.original_price - tour.pricing.base_price)}
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onQuickBook?.(tour);
                  }}
                  className="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2 px-4 rounded-lg font-medium text-sm hover:from-blue-600 hover:to-blue-700 transition-all"
                >
                  จองทันที
                </button>
                <Link href={tour.metadata.canonical_url}>
                  <button className="px-4 py-2 border border-blue-500 text-blue-500 rounded-lg font-medium text-sm hover:bg-blue-50 transition-all">
                    ดูเพิ่มเติม
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Prototype 1: Minimal Card with Slide Expand (simplified for space)
const Prototype1: React.FC<CompactTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const { isExpanded, progress, elementRef, toggleExpand } = useAutoExpand();
  const formatPrice = (price: number) => price.toLocaleString('th-TH');

  return (
    <div ref={elementRef} className="relative mb-6">
      <div className="bg-white rounded-xl border shadow-md hover:shadow-lg transition-all">
        <div className="flex items-center p-2 cursor-pointer" onClick={toggleExpand}>
          <div className="relative w-16 h-16 rounded overflow-hidden">
            <Image src={tour.media.hero_image} alt={tour.title} fill className="object-cover" />
          </div>
          <div className="flex-1 ml-3 min-w-0">
            <h3 className="font-medium text-sm line-clamp-1 text-gray-900 mb-1">{tour.title}</h3>
            <div className="flex items-center gap-3 text-xs text-gray-600">
              <span>★ {tour.quality.rating}</span>
              <span>{tour.duration_days}วัน{tour.nights}คืน</span>
              <span className="text-blue-600 font-medium">฿{formatPrice(tour.pricing.base_price)}</span>
            </div>
          </div>
        </div>
        {isExpanded && (
          <div className="border-t border-gray-100 p-4">
            <p className="text-sm text-gray-600 mb-4">{tour.title}</p>
            <div className="flex gap-2">
              <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg font-medium">จองเลย</button>
              <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-4 rounded-lg font-medium">ดูรายละเอียด</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Prototype 2: Card with Side Progress Ring (simplified)
const Prototype2: React.FC<CompactTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const { isExpanded, progress, elementRef, toggleExpand } = useAutoExpand();
  const formatPrice = (price: number) => price.toLocaleString('th-TH');

  return (
    <div ref={elementRef} className="relative mb-6">
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all">
        <div className="flex p-4 cursor-pointer" onClick={toggleExpand}>
          <div className="relative w-32 h-28 rounded-lg overflow-hidden">
            <Image src={tour.media.hero_image} alt={tour.title} fill className="object-cover" />
          </div>
          <div className="flex-1 ml-4">
            <h3 className="font-bold text-base mb-2 line-clamp-2">{tour.title}</h3>
            <div className="flex items-center gap-3 mb-2">
              <div className="flex items-center bg-yellow-50 px-2 py-1 rounded">
                <span className="text-sm font-semibold">★ {tour.quality.rating}</span>
              </div>
            </div>
            <div className="flex items-end justify-between">
              <span className="text-xl font-bold text-blue-600">฿{formatPrice(tour.pricing.base_price)}</span>
              <button className="px-3 py-1.5 bg-gray-100 rounded-lg text-sm">
                {isExpanded ? 'ซ่อน' : 'ดูเพิ่ม'}
              </button>
            </div>
          </div>
        </div>
        {isExpanded && (
          <div className="border-t border-gray-100 p-4">
            <p className="text-sm text-gray-600 mb-4">{tour.title}</p>
            <div className="flex gap-2">
              <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg font-medium">จองด่วน</button>
              <button className="px-6 py-2 border-2 border-blue-500 text-blue-600 rounded-lg font-semibold">รายละเอียด</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Prototype 4: Enhanced Larger Compact Card - Beautiful Mobile First Design
const Prototype4: React.FC<CompactTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const { isExpanded, progress, elementRef, toggleExpand } = useAutoExpand();
  const formatPrice = (price: number) => price.toLocaleString('th-TH');
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0;
  const [isAnimating, setIsAnimating] = useState(false);

  // Handle smooth animation state
  useEffect(() => {
    if (isExpanded !== undefined) {
      setIsAnimating(true);
      const timer = setTimeout(() => setIsAnimating(false), 700);
      return () => clearTimeout(timer);
    }
  }, [isExpanded]);

  // Mock data for airline and travel period since it's not in tour object
  const getAirlineInfo = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'Thai Airways (TG)';
      case 'เกาหลีใต้': return 'Korean Air (KE)';
      case 'ไต้หวัน': return 'EVA Air (BR)';
      case 'ยุโรป': return 'Emirates (EK)';
      case 'จีน': return 'China Airlines (CI)';
      case 'สิงคโปร์': return 'Singapore Airlines (SQ)';
      case 'มาเลเซีย': return 'Malaysia Airlines (MH)';
      case 'ฮ่องกง': return 'Cathay Pacific (CX)';
      default: return 'Thai Airways (TG)';
    }
  };

  const getTravelPeriod = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'ก.ย. 68 – เม.ย. 69';
      case 'เกาหลีใต้': return 'ต.ค. 68 – มี.ค. 69';
      case 'ไต้หวัน': return 'ก.ย. 68 – ก.พ. 69';
      case 'ยุโรป': return 'เม.ย. 68 – ต.ค. 68';
      case 'จีน': return 'ตลอดปี';
      case 'สิงคโปร์': return 'ตลอดปี';
      case 'มาเลเซีย': return 'ตลอดปี';
      case 'ฮ่องกง': return 'ต.ค. 68 – เม.ย. 69';
      default: return 'ก.ย. 68 – ก.พ. 69';
    }
  };

  return (
    <div ref={elementRef} className="relative mb-4 sm:mb-6">
      {/* Clean Loading Indicator - Best Practice */}
      {progress > 0 && progress < 100 && !isExpanded && (
        <>
          {/* Progress Bar Only */}
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gray-100 rounded-t-2xl z-10 pointer-events-none overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-t-2xl"
              style={{
                width: `${progress}%`,
                transition: 'width 100ms ease-out',
                willChange: 'width'
              }}
            />
          </div>
        </>
      )}

      <div 
        className={`
          bg-white rounded-xl border transition-all duration-700 ease-in-out overflow-hidden will-change-transform
          ${isExpanded ? 'shadow-2xl border-blue-500/50' : 'shadow-md border-gray-200 hover:shadow-lg'}
          ${isAnimating ? 'transform-gpu' : ''}
          ${progress > 0 && progress < 100 && !isExpanded ? 'ring-1 ring-blue-500/10' : ''}
        `}
      >
        {/* Enhanced Compact View - Redesigned with Better Height */}
        <div 
          className={`
            cursor-pointer transition-all duration-300 ease-out
            ${isExpanded ? 'opacity-0 max-h-0 overflow-hidden pointer-events-none' : 'opacity-100'}
          `}
          onClick={toggleExpand}
        >
          <div className="flex flex-col sm:flex-row p-4 sm:p-5 md:p-6 gap-4 sm:gap-5 min-h-[140px] sm:min-h-[120px] md:min-h-[140px] lg:min-h-[160px]">
            {/* Image Section - Full width on mobile, left side on larger screens */}
            <div className="relative w-full sm:w-32 md:w-40 lg:w-48 h-32 sm:h-full flex-shrink-0 rounded-xl overflow-hidden shadow-md">
              <Image
                src={tour.media.hero_image}
                alt={tour.title}
                fill
                className="object-cover"
              />
              {hasDiscount && (
                <div className="absolute top-2 left-2 bg-gradient-to-r from-red-500 to-red-600 text-white text-xs font-bold px-2.5 py-1 rounded-full shadow-lg">
                  -{tour.pricing.discount_percentage}%
                </div>
              )}
              {/* Duration Badge */}
              <div className="absolute bottom-2 left-2 bg-black/80 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-lg">
                {tour.duration_days}วัน{tour.nights}คืน
              </div>
            </div>

            {/* Content Section */}
            <div className="flex-1 flex flex-col justify-between min-w-0 space-y-3">
              {/* Header - Country & Title */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-base sm:text-lg md:text-xl font-bold text-gray-800">
                    {tour.location.country}
                  </span>
                  {tour.location.cities?.[0] && (
                    <>
                      <span className="text-gray-400">•</span>
                      <span className="text-sm sm:text-base text-gray-600">
                        {tour.location.cities[0]}
                      </span>
                    </>
                  )}
                </div>
                <h3 className="font-semibold text-sm sm:text-base md:text-lg text-gray-900 line-clamp-2 leading-snug">
                  {tour.title}
                </h3>
              </div>

              {/* Details Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm">
                <div className="flex items-center text-gray-600">
                  <svg className="w-4 h-4 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  <span className="truncate">{getAirlineInfo(tour.location.country)}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <svg className="w-4 h-4 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span className="truncate">{getTravelPeriod(tour.location.country)}</span>
                </div>
              </div>

              {/* Bottom Section - Rating & Price */}
              <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                <div className="flex items-center space-x-1">
                  <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                    <svg className="w-4 h-4 text-yellow-400 fill-current mr-1" viewBox="0 0 20 20">
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg>
                    <span className="text-xs font-semibold text-gray-800">{tour.quality.rating}</span>
                  </div>
                  <span className="text-xs text-gray-500">({tour.quality.review_count})</span>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-lg sm:text-xl font-bold text-blue-600">
                      ฿{formatPrice(tour.pricing.base_price)}
                    </div>
                    <div className="text-xs text-gray-500">ต่อคน</div>
                  </div>
                  
                  <button
                    className={`
                      p-2 rounded-lg transition-all duration-300 flex-shrink-0
                      ${isExpanded 
                        ? 'rotate-180 bg-blue-100 text-blue-600' 
                        : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
                      }
                    `}
                    aria-label={isExpanded ? 'ซ่อนรายละเอียด' : 'ดูรายละเอียด'}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Expanded Content */}
        <div 
          className={`
            transition-all duration-400 ease-out border-t border-gray-100
            ${isExpanded 
              ? 'opacity-100 max-h-screen transform translate-y-0' 
              : 'opacity-0 max-h-0 overflow-hidden transform -translate-y-2'
            }
          `}
          style={{
            transitionDelay: isExpanded ? '150ms' : '0ms'
          }}
        >
          {/* Image Section */}
          <div className="relative h-48 md:h-52">
            <Image
              src={tour.media.hero_image}
              alt={tour.title}
              fill
              className="object-cover"
              sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
            />
            
            {/* Overlays */}
            <div className="absolute top-3 left-3 right-3 flex justify-between items-start">
              {hasDiscount && (
                <span className="bg-red-100 text-red-600 text-sm px-3 py-1 rounded-full font-bold">
                  ลด {tour.pricing.discount_percentage}%
                </span>
              )}
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onWishlistToggle?.(tour.metadata.id);
                }}
                className="bg-white/90 backdrop-blur-sm rounded-full p-2"
                aria-label={isWishlisted ? 'ลบจากรายการโปรด' : 'เพิ่มในรายการโปรด'}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
              </button>
            </div>
            
            {/* Duration Badge */}
            <div className="absolute bottom-3 left-3">
              <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-sm font-medium flex items-center">
                <Clock className="w-4 h-4 mr-1 text-blue-600" />
                {tour.duration_days}วัน{tour.nights}คืน
              </div>
            </div>
          </div>
          
          {/* Content Section */}
          <div className="p-4">
            {/* Title */}
            <h3 className="font-semibold text-gray-900 text-base mb-2 line-clamp-2 leading-tight">
              {tour.title}
            </h3>
            
            {/* Enhanced Location Info */}
            <div className="flex items-center gap-2 mb-3 text-sm">
              <div className="flex items-center text-gray-600">
                <MapPin className="w-4 h-4 mr-1 flex-shrink-0" />
                <span className="font-medium">{tour.location.country}</span>
              </div>
              {tour.location.cities && tour.location.cities.length > 0 && (
                <span className="text-gray-600">
                  {tour.location.cities.slice(0, 5).join(', ')}
                </span>
              )}
            </div>
            
            {/* Highlights */}
            <div className="flex flex-wrap gap-2 mb-3">
              {tour.highlights.slice(0, 3).map((highlight, idx) => (
                <span key={idx} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-lg">
                  {typeof highlight === 'string' ? highlight : highlight.text}
                </span>
              ))}
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-3 mb-4">
              <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold text-sm">{tour.quality.rating}</span>
              </div>
              <span className="text-gray-500 text-sm">({tour.quality.review_count} รีวิว)</span>
              <div className="flex items-center text-green-600 text-xs">
                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="font-medium">รีวิวจริง</span>
              </div>
            </div>

            {/* Enhanced information for Prototype 3 */}
            <div className="bg-gray-50 rounded-lg p-3 mb-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">สายการบิน:</span>
                  <div className="font-medium">{getAirlineInfo(tour.location.country)}</div>
                </div>
                <div>
                  <span className="text-gray-600">ช่วงเวลาเดินทาง:</span>
                  <div className="font-medium">{getTravelPeriod(tour.location.country)}</div>
                </div>
              </div>
            </div>

            {/* Price & CTA */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div>
                {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                  <span className="text-sm text-gray-400 line-through mr-2">
                    ฿{formatPrice(tour.pricing.original_price)}
                  </span>
                )}
                <span className="text-2xl font-bold text-blue-600">
                  ฿{formatPrice(tour.pricing.base_price)}
                </span>
                <div className="text-xs text-gray-500">ต่อคน</div>
                {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                  <div className="text-xs text-green-600 font-medium">
                    ประหยัด ฿{formatPrice(tour.pricing.original_price - tour.pricing.base_price)}
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onQuickBook?.(tour);
                  }}
                  className="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2 px-4 rounded-lg font-medium text-sm hover:from-blue-600 hover:to-blue-700 transition-all"
                >
                  จองทันที
                </button>
                <Link href={tour.metadata.canonical_url}>
                  <button className="px-4 py-2 border border-blue-500 text-blue-500 rounded-lg font-medium text-sm hover:bg-blue-50 transition-all">
                    ดูเพิ่มเติม
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Prototype 5: Enhanced Compact Card with Smooth/Bounce Expand Animation
const Prototype5: React.FC<CompactTourCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const { isExpanded, progress, elementRef, toggleExpand } = useAutoExpand();
  const formatPrice = (price: number) => price.toLocaleString('th-TH');
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0;
  const [isAnimating, setIsAnimating] = useState(false);

  // Enhanced smooth animation state with bounce
  useEffect(() => {
    if (isExpanded !== undefined) {
      setIsAnimating(true);
      const timer = setTimeout(() => setIsAnimating(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [isExpanded]);

  // Mock data for airline and travel period since it's not in tour object
  const getAirlineInfo = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'Thai Airways (TG)';
      case 'เกาหลีใต้': return 'Korean Air (KE)';
      case 'ไต้หวัน': return 'EVA Air (BR)';
      case 'ยุโรป': return 'Emirates (EK)';
      case 'จีน': return 'China Airlines (CI)';
      case 'สิงคโปร์': return 'Singapore Airlines (SQ)';
      case 'มาเลเซีย': return 'Malaysia Airlines (MH)';
      case 'ฮ่องกง': return 'Cathay Pacific (CX)';
      default: return 'Thai Airways (TG)';
    }
  };

  const getTravelPeriod = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'ก.ย. 68 – เม.ย. 69';
      case 'เกาหลีใต้': return 'ต.ค. 68 – มี.ค. 69';
      case 'ไต้หวัน': return 'ก.ย. 68 – ก.พ. 69';
      case 'ยุโรป': return 'เม.ย. 68 – ต.ค. 68';
      case 'จีน': return 'ตลอดปี';
      case 'สิงคโปร์': return 'ตลอดปี';
      case 'มาเลเซีย': return 'ตลอดปี';
      case 'ฮ่องกง': return 'ต.ค. 68 – เม.ย. 69';
      default: return 'ก.ย. 68 – ก.พ. 69';
    }
  };

  return (
    <div ref={elementRef} className="relative mb-4 sm:mb-6">
      {/* Clean Loading Indicator - Best Practice */}
      {progress > 0 && progress < 100 && !isExpanded && (
        <>
          {/* Progress Bar Only */}
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gray-100 rounded-t-2xl z-10 pointer-events-none overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-t-2xl"
              style={{
                width: `${progress}%`,
                transition: 'width 100ms ease-out',
                willChange: 'width'
              }}
            />
          </div>
        </>
      )}

      <div 
        className={`
          bg-white rounded-xl border overflow-hidden will-change-transform
          ${isExpanded 
            ? 'shadow-2xl border-blue-500/50 transform scale-[1.02]' 
            : 'shadow-md border-gray-200 hover:shadow-lg transform scale-100'
          }
          ${isAnimating ? 'transform-gpu' : ''}
          ${progress > 0 && progress < 100 && !isExpanded ? 'ring-1 ring-blue-500/10' : ''}
          transition-all duration-700 ease-[cubic-bezier(0.175,0.885,0.32,1.275)]
        `}
      >
        {/* Enhanced Compact View - Redesigned with Better Height */}
        <div 
          className={`
            cursor-pointer transition-all duration-500 ease-[cubic-bezier(0.175,0.885,0.32,1.275)]
            ${isExpanded 
              ? 'opacity-0 max-h-0 overflow-hidden pointer-events-none transform scale-95' 
              : 'opacity-100 transform scale-100'
            }
          `}
          onClick={toggleExpand}
        >
          <div className="flex flex-col sm:flex-row p-4 sm:p-5 md:p-6 gap-4 sm:gap-5 min-h-[140px] sm:min-h-[120px] md:min-h-[140px] lg:min-h-[160px]">
            {/* Image Section - Full width on mobile, left side on larger screens */}
            <div className="relative w-full sm:w-32 md:w-40 lg:w-48 h-32 sm:h-full flex-shrink-0 rounded-xl overflow-hidden shadow-md">
              <Image
                src={tour.media.hero_image}
                alt={tour.title}
                fill
                className="object-cover"
              />
              {hasDiscount && (
                <div className="absolute top-2 left-2 bg-gradient-to-r from-red-500 to-red-600 text-white text-xs font-bold px-2.5 py-1 rounded-full shadow-lg">
                  -{tour.pricing.discount_percentage}%
                </div>
              )}
              {/* Duration Badge */}
              <div className="absolute bottom-2 left-2 bg-black/80 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-lg">
                {tour.duration_days}วัน{tour.nights}คืน
              </div>
            </div>

            {/* Content Section */}
            <div className="flex-1 flex flex-col justify-between min-w-0 space-y-3">
              {/* Header - Country & Title */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-base sm:text-lg md:text-xl font-bold text-gray-800">
                    {tour.location.country}
                  </span>
                  {tour.location.cities?.[0] && (
                    <>
                      <span className="text-gray-400">•</span>
                      <span className="text-sm sm:text-base text-gray-600">
                        {tour.location.cities[0]}
                      </span>
                    </>
                  )}
                </div>
                <h3 className="font-semibold text-sm sm:text-base md:text-lg text-gray-900 line-clamp-2 leading-snug">
                  {tour.title}
                </h3>
              </div>

              {/* Details Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm">
                <div className="flex items-center text-gray-600">
                  <svg className="w-4 h-4 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  <span className="truncate">{getAirlineInfo(tour.location.country)}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <svg className="w-4 h-4 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span className="truncate">{getTravelPeriod(tour.location.country)}</span>
                </div>
              </div>

              {/* Bottom Section - Rating & Price */}
              <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                <div className="flex items-center space-x-1">
                  <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                    <svg className="w-4 h-4 text-yellow-400 fill-current mr-1" viewBox="0 0 20 20">
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg>
                    <span className="text-xs font-semibold text-gray-800">{tour.quality.rating}</span>
                  </div>
                  <span className="text-xs text-gray-500">({tour.quality.review_count})</span>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-lg sm:text-xl font-bold text-blue-600">
                      ฿{formatPrice(tour.pricing.base_price)}
                    </div>
                    <div className="text-xs text-gray-500">ต่อคน</div>
                  </div>
                  
                  <button
                    className={`
                      p-2 rounded-lg flex-shrink-0
                      ${isExpanded 
                        ? 'rotate-180 bg-blue-100 text-blue-600 scale-110' 
                        : 'bg-gray-50 text-gray-500 hover:bg-gray-100 hover:scale-105'
                      }
                      transition-all duration-300 ease-[cubic-bezier(0.175,0.885,0.32,1.275)]
                    `}
                    aria-label={isExpanded ? 'ซ่อนรายละเอียด' : 'ดูรายละเอียด'}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Expanded Content - ใช้เหมือน Prototype 4 แต่ปรับ animation */}
        <div 
          className={`
            transition-all duration-500 ease-[cubic-bezier(0.175,0.885,0.32,1.275)] border-t border-gray-100
            ${isExpanded 
              ? 'opacity-100 max-h-screen transform translate-y-0' 
              : 'opacity-0 max-h-0 overflow-hidden transform -translate-y-2'
            }
          `}
          style={{
            transitionDelay: isExpanded ? '150ms' : '0ms'
          }}
        >
          {/* Image Section */}
          <div className="relative h-48 md:h-52">
            <Image
              src={tour.media.hero_image}
              alt={tour.title}
              fill
              className="object-cover"
              sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
            />
            
            {/* Overlays */}
            <div className="absolute top-3 left-3 right-3 flex justify-between items-start">
              {hasDiscount && (
                <span className="bg-red-100 text-red-600 text-sm px-3 py-1 rounded-full font-bold">
                  ลด {tour.pricing.discount_percentage}%
                </span>
              )}
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onWishlistToggle?.(tour.metadata.id);
                }}
                className="bg-white/90 backdrop-blur-sm rounded-full p-2"
                aria-label={isWishlisted ? 'ลบจากรายการโปรด' : 'เพิ่มในรายการโปรด'}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
              </button>
            </div>
            
            {/* Duration Badge */}
            <div className="absolute bottom-3 left-3">
              <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-sm font-medium flex items-center">
                <Clock className="w-4 h-4 mr-1 text-blue-600" />
                {tour.duration_days}วัน{tour.nights}คืน
              </div>
            </div>
          </div>
          
          {/* Content Section */}
          <div className="p-4">
            {/* Title */}
            <h3 className="font-semibold text-gray-900 text-base mb-2 line-clamp-2 leading-tight">
              {tour.title}
            </h3>
            
            {/* Enhanced Location Info */}
            <div className="flex items-center gap-2 mb-3 text-sm">
              <div className="flex items-center text-gray-600">
                <MapPin className="w-4 h-4 mr-1 flex-shrink-0" />
                <span className="font-medium">{tour.location.country}</span>
              </div>
              {tour.location.cities && tour.location.cities.length > 0 && (
                <span className="text-gray-600">
                  {tour.location.cities.slice(0, 5).join(', ')}
                </span>
              )}
            </div>
            
            {/* Highlights */}
            <div className="flex flex-wrap gap-2 mb-3">
              {tour.highlights.slice(0, 3).map((highlight, idx) => (
                <span key={idx} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-lg">
                  {typeof highlight === 'string' ? highlight : highlight.text}
                </span>
              ))}
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-3 mb-4">
              <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold text-sm">{tour.quality.rating}</span>
              </div>
              <span className="text-gray-500 text-sm">({tour.quality.review_count} รีวิว)</span>
              <div className="flex items-center text-green-600 text-xs">
                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="font-medium">รีวิวจริง</span>
              </div>
            </div>

            {/* Enhanced information for Prototype 4 */}
            <div className="bg-gray-50 rounded-lg p-3 mb-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">สายการบิน:</span>
                  <div className="font-medium">{getAirlineInfo(tour.location.country)}</div>
                </div>
                <div>
                  <span className="text-gray-600">ช่วงเวลาเดินทาง:</span>
                  <div className="font-medium">{getTravelPeriod(tour.location.country)}</div>
                </div>
              </div>
            </div>

            {/* Price & CTA */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div>
                {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                  <span className="text-sm text-gray-400 line-through mr-2">
                    ฿{formatPrice(tour.pricing.original_price)}
                  </span>
                )}
                <span className="text-2xl font-bold text-blue-600">
                  ฿{formatPrice(tour.pricing.base_price)}
                </span>
                <div className="text-xs text-gray-500">ต่อคน</div>
                {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                  <div className="text-xs text-green-600 font-medium">
                    ประหยัด ฿{formatPrice(tour.pricing.original_price - tour.pricing.base_price)}
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onQuickBook?.(tour);
                  }}
                  className="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2 px-4 rounded-lg font-medium text-sm hover:from-blue-600 hover:to-blue-700 transition-all"
                >
                  จองทันที
                </button>
                <Link href={tour.metadata.canonical_url}>
                  <button className="px-4 py-2 border border-blue-500 text-blue-500 rounded-lg font-medium text-sm hover:bg-blue-50 transition-all">
                    ดูเพิ่มเติม
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main Component Selector
interface CompactTourCardSelectorProps {
  tour: SearchIndexTour;
  prototype: 1 | 2 | 3 | 4 | 5;
  isWishlisted?: boolean;
  onWishlistToggle?: (tourId: string) => void;
  onQuickBook?: (tour: SearchIndexTour) => void;
}

const CompactTourCard: React.FC<CompactTourCardSelectorProps> = ({
  tour,
  prototype = 2,
  isWishlisted = false,
  onWishlistToggle,
  onQuickBook
}) => {
  const props = { tour, isWishlisted, onWishlistToggle, onQuickBook };

  switch (prototype) {
    case 1:
      return <Prototype1 {...props} />;
    case 2:
      return <Prototype2 {...props} />;
    case 3:
      return <Prototype3 {...props} />;
    case 4:
      return <Prototype4 {...props} />;
    case 5:
      return <Prototype5 {...props} />;
    default:
      return <Prototype2 {...props} />;
  }
};

export default CompactTourCard;