// ===================================================================
// tour-search-32: Main Search Page
// ===================================================================
// Complete mobile-first tour search implementation from scratch
// No dependencies on existing tour-search implementations

'use client'

import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react'
import { 
  Search, Filter, X, MapPin, Calendar, Star, TrendingUp, 
  ChevronDown, ArrowUp, MessageCircle, Phone, Sparkles,
  Users, Clock, Gift, Zap, Globe, Heart
} from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { searchIndex } from './data-etl'
import { SearchFilters, SearchIndexTour, SearchSortOptions } from './types'
import { TS32_TOKENS, TS32_CSS_VARS } from './design-system'
import { useSEO } from './seo'
import { useAccessibility, AriaManager } from './accessibility'
import { useAnalytics, useSearchPerformance } from './analytics'
import {
  Button,
  Input,
  Badge,
  Card,
  SearchBar,
  TourCardComponent,
  ViewToggle,
  SortDropdown,
  SearchResultsSkeleton
} from './components'

// ===================================================================
// Embedded Styles (Scoped CSS)
// ===================================================================
const tourSearchStyles = `
  .ts32-container {
    font-family: ${TS32_TOKENS.typography.fonts.thai};
    min-height: 100vh;
    background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  }
  
  .ts32-header {
    background: white;
    border-bottom: 1px solid ${TS32_TOKENS.colors.gray[200]};
    position: sticky;
    top: 0;
    z-index: ${TS32_TOKENS.zIndex.sticky};
    backdrop-filter: blur(8px);
  }
  
  .ts32-hero-section {
    background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 50%, #6366f1 100%);
    color: white;
    position: relative;
    overflow: hidden;
  }
  
  .ts32-hero-pattern {
    position: absolute;
    inset: 0;
    background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.1) 1px, transparent 0);
    background-size: 20px 20px;
  }
  
  .ts32-search-container {
    background: white;
    border-radius: ${TS32_TOKENS.radius['2xl']};
    box-shadow: ${TS32_TOKENS.shadows.xl};
    padding: ${TS32_TOKENS.spacing[6]};
    margin: 0 ${TS32_TOKENS.spacing[4]};
    transform: translateY(-50%);
    position: relative;
    z-index: 10;
  }
  
  .ts32-popular-destinations {
    background: white;
    border-radius: ${TS32_TOKENS.radius['2xl']};
    box-shadow: ${TS32_TOKENS.shadows.sm};
    padding: ${TS32_TOKENS.spacing[6]};
    margin: ${TS32_TOKENS.spacing[6]} ${TS32_TOKENS.spacing[4]};
  }
  
  .ts32-destination-card {
    position: relative;
    aspect-ratio: 1;
    border-radius: ${TS32_TOKENS.radius.xl};
    overflow: hidden;
    cursor: pointer;
    transition: transform ${TS32_TOKENS.motion.duration.normal} ${TS32_TOKENS.motion.ease.out};
  }
  
  .ts32-destination-card:hover {
    transform: scale(1.05);
  }
  
  /* Flash Sale Card Animation */
  .flash-sale-card {
    position: relative;
    border: 2px solid transparent;
    background: linear-gradient(white, white) padding-box,
                linear-gradient(45deg, #ef4444, #f59e0b, #ef4444) border-box;
    animation: flashSalePulse 2s ease-in-out infinite;
  }
  
  @keyframes flashSalePulse {
    0%, 100% {
      border-color: #ef4444;
      box-shadow: 0 0 20px rgba(239, 68, 68, 0.3);
    }
    50% {
      border-color: #f59e0b;
      box-shadow: 0 0 30px rgba(245, 158, 11, 0.4);
    }
  }
  
  .flash-sale-card::before {
    content: '';
    position: absolute;
    inset: -2px;
    background: linear-gradient(45deg, #ef4444, #f59e0b, #dc2626, #f59e0b);
    background-size: 200% 200%;
    border-radius: inherit;
    z-index: -1;
    animation: flashSaleGradient 3s ease infinite;
  }
  
  @keyframes flashSaleGradient {
    0%, 100% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
  }
  
  .ts32-destination-card::after {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.2) 50%, transparent 100%);
  }
  
  .ts32-filter-drawer {
    position: fixed;
    inset: 0;
    z-index: ${TS32_TOKENS.zIndex.modal};
    background: rgba(0, 0, 0, 0.5);
  }
  
  .ts32-filter-content {
    position: fixed;
    right: 0;
    top: 0;
    bottom: 0;
    width: 100%;
    max-width: 400px;
    background: white;
    overflow-y: auto;
    transform: translateX(100%);
    transition: transform ${TS32_TOKENS.motion.duration.normal} ${TS32_TOKENS.motion.ease.out};
  }
  
  .ts32-filter-content.open {
    transform: translateX(0);
  }
  
  .ts32-controls-bar {
    background: white;
    border-bottom: 1px solid ${TS32_TOKENS.colors.gray[200]};
    padding: ${TS32_TOKENS.spacing[4]};
    position: sticky;
    top: 64px;
    z-index: ${TS32_TOKENS.zIndex.docked};
  }
  
  .ts32-results-grid {
    display: grid;
    gap: ${TS32_TOKENS.spacing[6]};
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  }
  
  .ts32-results-list {
    display: flex;
    flex-direction: column;
    gap: ${TS32_TOKENS.spacing[4]};
  }
  
  .ts32-sticky-cta {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: white;
    border-top: 1px solid ${TS32_TOKENS.colors.gray[200]};
    padding: ${TS32_TOKENS.spacing[4]};
    z-index: ${TS32_TOKENS.zIndex.docked};
    box-shadow: ${TS32_TOKENS.shadows.lg};
  }
  
  .ts32-back-to-top {
    position: fixed;
    bottom: 100px;
    right: ${TS32_TOKENS.spacing[4]};
    z-index: ${TS32_TOKENS.zIndex.docked};
    transform: translateY(100px);
    transition: transform ${TS32_TOKENS.motion.duration.normal} ${TS32_TOKENS.motion.ease.out};
  }
  
  .ts32-back-to-top.visible {
    transform: translateY(0);
  }
  
  @media (min-width: ${TS32_TOKENS.breakpoints.md}) {
    .ts32-search-container {
      margin: 0 ${TS32_TOKENS.spacing[8]};
      padding: ${TS32_TOKENS.spacing[8]};
    }
    
    .ts32-popular-destinations {
      margin: ${TS32_TOKENS.spacing[8]};
      padding: ${TS32_TOKENS.spacing[8]};
    }
    
    .ts32-filter-content {
      width: 400px;
    }
  }
  
  @media (min-width: ${TS32_TOKENS.breakpoints.lg}) {
    .ts32-results-grid {
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    }
  }
  
  @keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
  }
  
  .ts32-skeleton {
    animation: shimmer 2s infinite;
  }
  
  /* Accessibility Classes */
  .sr-only {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    padding: 0 !important;
    margin: -1px !important;
    overflow: hidden !important;
    clip: rect(0, 0, 0, 0) !important;
    white-space: nowrap !important;
    border: 0 !important;
  }
  
  /* Focus management */
  .ts32-container *:focus {
    outline: 2px solid ${TS32_TOKENS.colors.primary[500]} !important;
    outline-offset: 2px !important;
  }
  
  /* High contrast mode support */
  @media (prefers-contrast: high) {
    .ts32-container {
      background: white !important;
    }
    
    .ts32-header {
      border-bottom: 2px solid black !important;
    }
  }
  
  /* Reduced motion support */
  @media (prefers-reduced-motion: reduce) {
    .ts32-container *,
    .ts32-container *::before,
    .ts32-container *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }
`

// ===================================================================
// New Modern Filter Drawer Component
// ===================================================================

interface FilterDrawerProps {
  isOpen: boolean
  onClose: () => void
  filters: SearchFilters
  onFiltersChange: (filters: SearchFilters) => void
  totalResults: number
}

const FilterDrawer: React.FC<FilterDrawerProps> = ({
  isOpen,
  onClose,
  filters,
  onFiltersChange,
  totalResults
}) => {
  const [localFilters, setLocalFilters] = useState<SearchFilters>(filters)
  const [activeTab, setActiveTab] = useState<'destination' | 'budget' | 'experience'>('destination')
  
  const popularDestinations = useMemo(() => 
    searchIndex.getPopularDestinations(12), 
    []
  )
  
  const handleApplyFilters = () => {
    onFiltersChange(localFilters)
    onClose()
  }
  
  const handleClearFilters = () => {
    const clearedFilters: SearchFilters = {}
    setLocalFilters(clearedFilters)
    onFiltersChange(clearedFilters)
  }
  
  const updateFilter = <K extends keyof SearchFilters>(
    key: K, 
    value: SearchFilters[K]
  ) => {
    setLocalFilters(prev => ({ ...prev, [key]: value }))
  }
  
  useEffect(() => {
    setLocalFilters(filters)
  }, [filters])
  
  if (!isOpen) return null
  
  return (
    <div className="fixed inset-0 z-50">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      {/* Filter Content */}
      <div className="absolute top-0 right-0 h-full w-full max-w-lg bg-white shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900 flex items-center">
                <Filter className="w-6 h-6 mr-3 text-blue-600" />
                ตัวกรองการค้นหา
              </h2>
              <p className="text-sm text-gray-600 mt-1">ปรับแต่งการค้นหาให้เหมาะกับคุณ</p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose} className="hover:bg-white/50">
              <X className="w-5 h-5" />
            </Button>
          </div>
          
          {/* Filter Tabs */}
          <div className="flex bg-white rounded-xl p-1 shadow-sm">
            {[
              { id: 'destination', label: 'ปลายทาง', icon: MapPin },
              { id: 'budget', label: 'งบประมาณ', icon: Calendar },
              { id: 'experience', label: 'ประสบการณ์', icon: Star }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 flex items-center justify-center py-3 px-4 text-sm font-medium rounded-lg transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
                }`}
              >
                <tab.icon className="w-4 h-4 mr-2" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        
        {/* Filter Content */}
        <div className="flex-1 overflow-y-auto p-6 transition-all duration-300 ease-in-out">
          {activeTab === 'destination' && (
            <div className="space-y-6 animate-in fade-in-50 duration-300">
              {/* Popular Destinations */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Globe className="w-5 h-5 mr-2 text-blue-600" />
                  จุดหมายยอดนิยม
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {popularDestinations.map(dest => (
                    <Button
                      key={dest.country}
                      variant={localFilters.countries?.includes(dest.country) ? 'primary' : 'secondary'}
                      size="sm"
                      onClick={() => {
                        const countries = localFilters.countries || []
                        const newCountries = countries.includes(dest.country)
                          ? countries.filter(c => c !== dest.country)
                          : [...countries, dest.country]
                        updateFilter('countries', newCountries)
                      }}
                      className="justify-start"
                    >
                      <span className="truncate">{dest.country}</span>
                      <Badge variant="gray" className="ml-auto">
                        {dest.count}
                      </Badge>
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Duration Filter */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-purple-600" />
                  ระยะเวลา
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: '1-3 วัน', min: 1, max: 3 },
                    { label: '4-7 วัน', min: 4, max: 7 },
                    { label: '8-14 วัน', min: 8, max: 14 },
                    { label: '15+ วัน', min: 15, max: 999 }
                  ].map(duration => (
                    <Button
                      key={`${duration.min}-${duration.max}`}
                      variant={(localFilters.min_duration === duration.min && localFilters.max_duration === duration.max) ? 'primary' : 'secondary'}
                      size="sm"
                      onClick={() => {
                        if (localFilters.min_duration === duration.min && localFilters.max_duration === duration.max) {
                          updateFilter('min_duration', undefined)
                          updateFilter('max_duration', undefined)
                        } else {
                          updateFilter('min_duration', duration.min)
                          updateFilter('max_duration', duration.max)
                        }
                      }}
                    >
                      {duration.label}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Availability */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Users className="w-5 h-5 mr-2 text-red-600" />
                  ความพร้อม
                </h3>
                <div className="space-y-3">
                  <Button
                    variant={localFilters.available_only ? 'success' : 'secondary'}
                    size="md"
                    onClick={() => updateFilter('available_only', !localFilters.available_only)}
                    className="w-full justify-start"
                  >
                    เฉพาะทัวร์ที่มีที่นั่ง
                  </Button>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'มีที่นั่ง 5+ ที่', min: 5 },
                      { label: 'มีที่นั่ง 10+ ที่', min: 10 }
                    ].map(seats => (
                      <Button
                        key={seats.min}
                        variant={localFilters.min_seats === seats.min ? 'warning' : 'secondary'}
                        size="sm"
                        onClick={() => updateFilter('min_seats', 
                          localFilters.min_seats === seats.min ? undefined : seats.min
                        )}
                      >
                        {seats.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'budget' && (
            <div className="space-y-6 animate-in fade-in-50 duration-300">
              {/* Price Range */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Gift className="w-5 h-5 mr-2 text-green-600" />
                  ช่วงราคา
                </h3>
                <div className="grid grid-cols-1 gap-3">
                  {[
                    { label: 'ไม่เกิน 30,000 บาท', min: 0, max: 30000 },
                    { label: 'ไม่เกิน 50,000 บาท', min: 0, max: 50000 },
                    { label: 'ไม่เกิน 80,000 บาท', min: 0, max: 80000 },
                    { label: 'ไม่เกิน 120,000 บาท', min: 0, max: 120000 },
                    { label: '120,000 - 200,000 บาท', min: 120000, max: 200000 },
                    { label: 'มากกว่า 200,000 บาท', min: 200000, max: 999999 }
                  ].map(range => {
                const isSelected = localFilters.price_min === range.min && 
                                 localFilters.price_max === range.max
                return (
                  <Button
                    key={`${range.min}-${range.max}`}
                    variant={isSelected ? 'success' : 'secondary'}
                    size="sm"
                    onClick={() => {
                      if (isSelected) {
                        updateFilter('price_min', undefined)
                        updateFilter('price_max', undefined)
                      } else {
                        updateFilter('price_min', range.min)
                        updateFilter('price_max', range.max)
                      }
                    }}
                  >
                    {range.label}
                  </Button>
                )
              })}
                </div>
                
                {/* Promotion Filter */}
                <div className="mt-4">
                  <Button
                    variant={localFilters.has_promotion ? 'warning' : 'secondary'}
                    size="md"
                    onClick={() => updateFilter('has_promotion', !localFilters.has_promotion)}
                    leftIcon={<Sparkles className="w-4 h-4" />}
                    className="w-full"
                  >
                    เฉพาะโปรโมชั่น
                  </Button>
                </div>
              </div>
              
              {/* Rating */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Star className="w-5 h-5 mr-2 text-yellow-600" />
                  คะแนนรีวิว
                </h3>
                <div className="space-y-3">
                  {[
                    { label: '4.5+ ดาว (ดีเยี่ยม)', rating: 4.5 },
                    { label: '4.0+ ดาว (ดีมาก)', rating: 4.0 },
                    { label: '3.5+ ดาว (ดี)', rating: 3.5 },
                    { label: 'ทุกคะแนน', rating: 0 }
                  ].map(ratingOption => (
                    <Button
                      key={ratingOption.rating}
                      variant={localFilters.min_rating === ratingOption.rating ? 'warning' : 'secondary'}
                      size="sm"
                      onClick={() => updateFilter('min_rating', 
                        localFilters.min_rating === ratingOption.rating ? undefined : ratingOption.rating
                      )}
                      className="w-full justify-start"
                    >
                      {ratingOption.label}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}
        
        {activeTab === 'experience' && (
          <div className="space-y-6 animate-in fade-in-50 duration-300">
            {/* Themes */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Zap className="w-5 h-5 mr-2 text-indigo-600" />
                ธีมการเดินทาง
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: '🌿 ธรรมชาติ', value: 'nature' },
                  { label: '🏛️ วัฒนธรรม', value: 'culture' },
                  { label: '🍜 อาหาร', value: 'food' },
                  { label: '🛍️ ช้อปปิ้ง', value: 'shopping' },
                  { label: '⛰️ ผจญภัย', value: 'adventure' },
                  { label: '🛁 ผ่อนคลาย', value: 'relaxation' },
                  { label: '🏙️ ทันสมัย', value: 'modern' },
                  { label: '🎪 บันเทิง', value: 'entertainment' }
                ].map(theme => (
                  <Button
                    key={theme.value}
                    variant={localFilters.themes?.includes(theme.value) ? 'primary' : 'secondary'}
                    size="sm"
                    onClick={() => {
                      const themes = localFilters.themes || []
                      const newThemes = themes.includes(theme.value)
                        ? themes.filter(t => t !== theme.value)
                        : [...themes, theme.value]
                      updateFilter('themes', newThemes)
                    }}
                  >
                    {theme.label}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Trip Style */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Heart className="w-5 h-5 mr-2 text-pink-600" />
                สไตล์การเดินทาง
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {[
                  { label: '👥 เดินทางกลุ่ม', value: 'group' },
                  { label: '💑 คู่รัก/ฮันนีมูน', value: 'couple' },
                  { label: '👨‍👩‍👧‍👦 ครอบครัว', value: 'family' },
                  { label: '🎓 กลุ่มเพื่อน', value: 'friends' },
                  { label: '💼 ธุรกิจ/ประชุม', value: 'business' },
                  { label: '🧘‍♀️ เดี่ยว/พักผ่อน', value: 'solo' }
                ].map(style => (
                  <Button
                    key={style.value}
                    variant={localFilters.trip_style?.includes(style.value) ? 'primary' : 'secondary'}
                    size="sm"
                    onClick={() => {
                      const styles = localFilters.trip_style || []
                      const newStyles = styles.includes(style.value)
                        ? styles.filter(s => s !== style.value)
                        : [...styles, style.value]
                      updateFilter('trip_style', newStyles)
                    }}
                    className="justify-start"
                  >
                    {style.label}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Activity Level */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Zap className="w-5 h-5 mr-2 text-orange-600" />
                ระดับกิจกรรม
              </h3>
              <div className="space-y-3">
                {[
                  { label: '😌 ผ่อนคลาย - ไม่ต้องเดินเยอะ', value: 'relaxed' },
                  { label: '🚶‍♀️ ปานกลาง - เดินเที่ยวสบายๆ', value: 'moderate' },
                  { label: '🏃‍♀️ กระตือรือร้น - ผจญภัยเต็มที่', value: 'active' }
                ].map(level => (
                  <Button
                    key={level.value}
                    variant={localFilters.activity_level === level.value ? 'warning' : 'secondary'}
                    size="sm"
                    onClick={() => updateFilter('activity_level', 
                      localFilters.activity_level === level.value ? undefined : level.value
                    )}
                    className="w-full justify-start"
                  >
                    {level.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        )}
        </div>
        
        {/* Footer */}
        <div className="border-t border-gray-200 p-6 space-y-3">
          <Button
            variant="primary"
            size="lg"
            onClick={handleApplyFilters}
            className="w-full"
          >
            ดูผลลัพธ์ ({totalResults} ทัวร์)
          </Button>
          <Button
            variant="secondary"
            size="md"
            onClick={handleClearFilters}
            className="w-full"
          >
            ล้างตัวกรองทั้งหมด
          </Button>
        </div>
      </div>
    </div>
  )
}

// ===================================================================
// Lead Capture Modal (Simple)
// ===================================================================

interface LeadCaptureModalProps {
  isOpen: boolean
  onClose: () => void
  tour?: SearchIndexTour
}

const LeadCaptureModal: React.FC<LeadCaptureModalProps> = ({ isOpen, onClose, tour }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsSubmitting(false)
    setIsSuccess(true)
    
    // Auto close after success
    setTimeout(() => {
      setIsSuccess(false)
      onClose()
      setFormData({ name: '', email: '', phone: '', message: '' })
    }, 2000)
  }
  
  if (!isOpen) return null
  
  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h3 className="text-xl font-bold text-gray-900">สอบถามทัวร์</h3>
            {tour && (
              <p className="text-sm text-gray-600 mt-1 line-clamp-1">{tour.title}</p>
            )}
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Content */}
        <div className="p-6">
          {isSuccess ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">ส่งข้อมูลสำเร็จ!</h4>
              <p className="text-gray-600">ทีมงานจะติดต่อกลับภายใน 24 ชั่วโมง</p>
            </div>
          ) : (
            <>
              {/* Trust Signal */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <MessageCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  </div>
                  <div>
                    <h4 className="font-medium text-blue-900">ข้อมูลของคุณปลอดภัย</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      ทีมงานจะติดต่อกลับภายใน 24 ชั่วโมง เพื่อให้คำปรึกษาและแนะนำทัวร์ที่เหมาะกับคุณ
                    </p>
                  </div>
                </div>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  label="ชื่อ-นามสกุล *"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required
                  placeholder="กรุณากรอกชื่อ-นามสกุล"
                />
                
                <Input
                  label="เบอร์โทรศัพท์ *"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  required
                  placeholder="08X-XXX-XXXX"
                />
                
                <Input
                  label="อีเมล"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="your@email.com"
                />
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ข้อความเพิ่มเติม
                  </label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                    placeholder="เช่น ช่วงเวลาที่สะดวกเดินทาง, จำนวนผู้เดินทาง, งบประมาณ..."
                    rows={3}
                    className="w-full p-3 border border-gray-200 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  isLoading={isSubmitting}
                  className="w-full"
                  disabled={!formData.name || !formData.phone}
                >
                  {isSubmitting ? 'กำลังส่ง...' : 'ส่งข้อมูล'}
                </Button>
                
                <p className="text-xs text-gray-500 text-center">
                  การส่งข้อมูลแสดงว่าคุณยินยอมให้เราติดต่อกลับเพื่อให้คำปรึกษา
                </p>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

// ===================================================================
// Main Tour Search Component
// ===================================================================

export default function TourSearch32() {
  // State management
  const [searchQuery, setSearchQuery] = useState('')
  const [filters, setFilters] = useState<SearchFilters>({})
  const [sortOptions, setSortOptions] = useState<SearchSortOptions>({
    field: 'popularity',
    direction: 'desc'
  })
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card')
  const [showFilters, setShowFilters] = useState(false)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [wishlist, setWishlist] = useState<string[]>([])
  const [leadModal, setLeadModal] = useState<{
    isOpen: boolean
    tour?: SearchIndexTour
  }>({ isOpen: false })
  
  // Loading and data states
  const [isLoading, setIsLoading] = useState(true)
  const [isSearching, setIsSearching] = useState(false)
  
  // Refs
  const topRef = useRef<HTMLDivElement>(null)
  
  // SEO and Analytics hooks
  const seo = useSEO()
  const analytics = useAnalytics()
  const searchPerformance = useSearchPerformance()
  const a11y = useAccessibility()
  
  // Search and filter logic
  const searchResults = useMemo(() => {
    const combinedFilters: SearchFilters = {
      ...filters,
      query: searchQuery.trim() || undefined
    }
    
    return searchIndex.search(combinedFilters, sortOptions)
  }, [searchQuery, filters, sortOptions])
  
  const popularDestinations = useMemo(() => 
    searchIndex.getPopularDestinations(6), 
    []
  )
  
  const featuredTours = useMemo(() => 
    searchIndex.getFeaturedTours(6), 
    []
  )
  
  // Search suggestions
  const searchSuggestions = useMemo(() => {
    if (searchQuery.length < 2) return []
    
    const suggestions = new Set<string>()
    
    // Add popular destinations that match
    popularDestinations.forEach(dest => {
      if (dest.country.toLowerCase().includes(searchQuery.toLowerCase())) {
        suggestions.add(`ทัวร์${dest.country}`)
      }
    })
    
    // Add common search terms
    const commonTerms = [
      'ทัวร์ญี่ปุ่น ซากุระ', 'ทัวร์เกาหลี', 'ทัวร์ยุโรป', 
      'ทัวร์ราคาดี', 'ทัวร์โปรโมชั่น', 'ทัวร์ช่วงวันหยุด'
    ]
    
    commonTerms.forEach(term => {
      if (term.toLowerCase().includes(searchQuery.toLowerCase())) {
        suggestions.add(term)
      }
    })
    
    return Array.from(suggestions).slice(0, 5)
  }, [searchQuery, popularDestinations])
  
  // Event handlers
  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query)
    setIsSearching(true)
    
    // Simulate search delay
    setTimeout(() => setIsSearching(false), 300)
  }, [])
  
  const handleFiltersChange = useCallback((newFilters: SearchFilters) => {
    const oldFilters = filters
    setFilters(newFilters)
    
    // Track filter changes for analytics and accessibility
    Object.keys(newFilters).forEach(key => {
      const filterKey = key as keyof SearchFilters
      const oldValue = oldFilters[filterKey]
      const newValue = newFilters[filterKey]
      
      if (JSON.stringify(oldValue) !== JSON.stringify(newValue)) {
        if (newValue && (!oldValue || (Array.isArray(newValue) && newValue.length > 0))) {
          // Filter applied
          analytics.trackFilterApplied(
            filterKey,
            newValue,
            Object.keys(newFilters).filter(k => newFilters[k as keyof SearchFilters]).length,
            searchResults.length, // Will be updated in next render
            searchResults.length // Will be calculated with new filters
          )
          a11y.announceFilterChange(filterKey, 'applied', String(newValue))
        } else if (!newValue || (Array.isArray(newValue) && newValue.length === 0)) {
          // Filter removed
          analytics.trackFilterCleared(
            filterKey,
            Object.keys(newFilters).filter(k => newFilters[k as keyof SearchFilters]).length,
            searchResults.length,
            searchResults.length
          )
          a11y.announceFilterChange(filterKey, 'removed', String(oldValue))
        }
      }
    })
  }, [filters, analytics, a11y, searchResults.length])
  
  const handleWishlistToggle = useCallback((tourId: string) => {
    setWishlist(prev => {
      const newWishlist = prev.includes(tourId)
        ? prev.filter(id => id !== tourId)
        : [...prev, tourId]
      
      // Save to localStorage
      localStorage.setItem('ts32-wishlist', JSON.stringify(newWishlist))
      return newWishlist
    })
  }, [])
  
  const handleQuickBook = useCallback((tour: SearchIndexTour) => {
    // Track lead form opened
    analytics.trackLeadFormOpened(tour, 'quick_book')
    setLeadModal({ isOpen: true, tour })
  }, [analytics])

  const handleTourClick = useCallback((tour: SearchIndexTour, position: number) => {
    // Track tour click
    analytics.trackTourClick(tour, position, viewMode, 'search_results')
  }, [analytics, viewMode])
  
  const scrollToTop = useCallback(() => {
    topRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [])
  
  // Effects
  useEffect(() => {
    // Load wishlist from localStorage
    const savedWishlist = localStorage.getItem('ts32-wishlist')
    if (savedWishlist) {
      setWishlist(JSON.parse(savedWishlist))
    }
    
    // Simulate initial load
    setTimeout(() => setIsLoading(false), 1000)
  }, [])
  
  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 400)
    }
    
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // SEO and Analytics tracking
  useEffect(() => {
    // Track search performance
    if (searchQuery || Object.keys(filters).length > 0) {
      searchPerformance.startSearch(searchQuery, filters)
    }
  }, [searchQuery, filters, searchPerformance])

  useEffect(() => {
    // Complete search tracking and announce results
    if (!isSearching) {
      searchPerformance.endSearch(searchResults.length)
      a11y.announceSearchResults(searchQuery, searchResults.length, filters)
    }
  }, [searchResults, isSearching, searchQuery, filters, searchPerformance, a11y])

  useEffect(() => {
    // Update document meta tags for SEO
    const metaTags = seo.generateSearchPageMeta(searchQuery, filters, searchResults.length)
    
    // Update title
    document.title = metaTags.title
    
    // Update meta description
    let metaDescription = document.querySelector('meta[name="description"]')
    if (!metaDescription) {
      metaDescription = document.createElement('meta')
      metaDescription.setAttribute('name', 'description')
      document.head.appendChild(metaDescription)
    }
    metaDescription.setAttribute('content', metaTags.description)
    
    // Update canonical URL
    let canonicalLink = document.querySelector('link[rel="canonical"]')
    if (!canonicalLink) {
      canonicalLink = document.createElement('link')
      canonicalLink.setAttribute('rel', 'canonical')
      document.head.appendChild(canonicalLink)
    }
    canonicalLink.setAttribute('href', metaTags.canonical)
    
    // Add structured data
    const structuredData = seo.generateSearchPageStructuredData(
      searchQuery, 
      filters, 
      searchResults.slice(0, 10), 
      searchResults.length
    )
    
    let scriptTag = document.querySelector('#ts32-structured-data')
    if (!scriptTag) {
      scriptTag = document.createElement('script')
      scriptTag.id = 'ts32-structured-data'
      scriptTag.type = 'application/ld+json'
      document.head.appendChild(scriptTag)
    }
    scriptTag.textContent = JSON.stringify(structuredData)
  }, [searchQuery, filters, searchResults, seo])
  
  // Sort options
  const sortOptionsList = [
    { value: 'popularity', label: 'ความนิยม', description: 'ทัวร์ที่ได้รับความสนใจมากที่สุด' },
    { value: 'price-low', label: 'ราคาต่ำ → สูง', description: 'เรียงจากราคาถูกที่สุด' },
    { value: 'price-high', label: 'ราคาสูง → ต่ำ', description: 'เรียงจากราคาแพงที่สุด' },
    { value: 'rating', label: 'คะแนนสูงสุด', description: 'ทัวร์ที่ได้รับรีวิวดีที่สุด' },
    { value: 'departure_date', label: 'วันเดินทางใกล้สุด', description: 'เรียงตามวันออกเดินทาง' },
    { value: 'discount', label: 'ส่วนลดสูงสุด', description: 'โปรโมชั่นดีที่สุด' }
  ]
  
  const handleSortChange = (value: string) => {
    const [field, direction = 'desc'] = value.split('-')
    setSortOptions({
      field: field as SearchSortOptions['field'],
      direction: direction as 'asc' | 'desc'
    })
  }
  
  const currentSortValue = sortOptions.direction === 'asc' ? 
    `${sortOptions.field}-asc` : sortOptions.field
  
  // Calculate active filters count
  const activeFiltersCount = Object.values(filters).filter(value => {
    if (Array.isArray(value)) return value.length > 0
    return value !== undefined && value !== null && value !== ''
  }).length
  
  return (
    <div className="ts32-container">
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      <style>{tourSearchStyles}</style>
      
      {/* ARIA Live Regions for Screen Readers */}
      <div id="ts32-announcements" aria-live="polite" aria-atomic="true" className="sr-only" />
      <div id="ts32-search-status" aria-live="polite" aria-atomic="true" className="sr-only" />
      <div id="ts32-filter-status" aria-live="polite" aria-atomic="false" className="sr-only" />
      <div id="ts32-errors" aria-live="assertive" aria-atomic="true" className="sr-only" />
      
      <div ref={topRef} />
      
      {/* Header */}
      <header className="ts32-header">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-xl font-bold text-gray-900">
              TourWow
            </Link>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Phone className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">02-XXX-XXXX</span>
              </Button>
            </div>
          </div>
        </div>
      </header>
      
      {/* Hero Section */}
      <section className="ts32-hero-section py-16 md:py-20">
        <div className="ts32-hero-pattern" />
        <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
          <h1 className="text-3xl md:text-5xl font-bold mb-4">
            ค้นหาทัวร์ต่างประเทศ
          </h1>
          <p className="text-lg md:text-xl text-blue-100 mb-8">
            ทัวร์คุณภาพดี ราคาดี กว่า {searchIndex.getStats().total_tours.toLocaleString()} ทัวร์
          </p>
          
          {/* Hero Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            {[
              { label: 'ทัวร์ทั้งหมด', value: searchIndex.getStats().total_tours.toLocaleString() },
              { label: 'ประเทศ', value: searchIndex.getStats().countries.toString() },
              { label: 'ราคาเฉลี่ย', value: `฿${(searchIndex.getStats().avg_price / 1000).toFixed(0)}K` },
              { label: 'ธีมท่องเที่ยว', value: searchIndex.getStats().themes.toString() }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-sm text-blue-200">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Search Container */}
      <div className="ts32-search-container">
        <SearchBar
          id="ts32-search-input"
          value={searchQuery}
          onChange={setSearchQuery}
          onSearch={handleSearch}
          suggestions={searchSuggestions}
          isLoading={isSearching}
          aria-label="ค้นหาทัวร์และประสบการณ์ท่องเที่ยว"
          aria-describedby="ts32-search-help"
        />
        <div id="ts32-search-help" className="sr-only">
          พิมพ์คำค้นหาเพื่อค้นหาทัวร์ หรือกด / เพื่อเข้าสู่ช่องค้นหาด้วยแป้นพิมพ์
        </div>
      </div>
      
      {/* Popular Destinations */}
      <section className="ts32-popular-destinations">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">จุดหมายยอดนิยม</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
          {[
            { country: 'ญี่ปุ่น', count: 89, image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=300&h=300&fit=crop' },
            { country: 'เกาหลีใต้', count: 56, image: 'https://images.unsplash.com/photo-1517154421773-0529f29ea451?w=300&h=300&fit=crop' },
            { country: 'ไต้หวัน', count: 43, image: 'https://images.unsplash.com/photo-1562669301-0ac3e7446a12?w=300&h=300&fit=crop' },
            { country: 'ฮ่องกง', count: 32, image: 'https://images.unsplash.com/photo-1536599018102-9f803c140fc1?w=300&h=300&fit=crop' },
            { country: 'สิงคโปร์', count: 28, image: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=300&h=300&fit=crop' },
            { country: 'มาเลเซีย', count: 24, image: 'https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=300&h=300&fit=crop' }
          ].map((dest, index) => (
            <button
              key={dest.country}
              onClick={() => handleSearch(`ทัวร์${dest.country}`)}
              className="ts32-destination-card group"
            >
              <Image
                src={dest.image}
                alt={`ทัวร์${dest.country} - ภาพปลายทางยอดนิยม`}
                fill
                className="object-cover"
                sizes="(max-width: 640px) 50vw, (max-width: 768px) 33vw, 16vw"
              />
              <div className="absolute inset-0 flex flex-col justify-end p-3 z-10">
                <h3 className="text-white font-bold text-sm group-hover:scale-110 transition-transform">
                  {dest.country}
                </h3>
                <p className="text-white/80 text-xs">
                  {dest.count} ทัวร์
                </p>
              </div>
            </button>
          ))}
        </div>
      </section>
      
      {/* Controls Bar */}
      <div className="ts32-controls-bar">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <ViewToggle viewMode={viewMode} onChange={setViewMode} />
            
            <Button
              variant="secondary"
              onClick={() => setShowFilters(true)}
              leftIcon={<Filter className="w-4 h-4" />}
              rightIcon={activeFiltersCount > 0 ? (
                <Badge variant="primary" className="ml-2">
                  {activeFiltersCount}
                </Badge>
              ) : undefined}
            >
              ตัวกรอง
            </Button>
          </div>
          
          <div className="flex items-center space-x-4">
            <SortDropdown
              options={sortOptionsList}
              value={currentSortValue}
              onChange={handleSortChange}
            />
          </div>
        </div>
      </div>
      
      {/* Results Section */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Results Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900">
              ผลการค้นหา
            </h2>
            <p className="text-gray-600 text-sm">
              พบ {searchResults.length.toLocaleString()} ทัวร์
              {searchQuery && ` สำหรับ "${searchQuery}"`}
            </p>
          </div>
        </div>
        
        {/* Results Grid */}
        {isLoading ? (
          <SearchResultsSkeleton viewMode={viewMode} count={8} />
        ) : searchResults.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              ไม่พบทัวร์ที่ตรงกับเงื่อนไข
            </h3>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              ลองเปลี่ยนคำค้นหาหรือตัวกรองเพื่อค้นหาทัวร์ที่เหมาะกับคุณ
            </p>
            <Button
              variant="primary"
              onClick={() => {
                setSearchQuery('')
                setFilters({})
              }}
            >
              ล้างตัวกรองทั้งหมด
            </Button>
          </div>
        ) : (
          <div 
            className={viewMode === 'card' ? 'ts32-results-grid' : 'ts32-results-list'}
            data-tour-results
            data-view-mode={viewMode}
            {...AriaManager.generateSearchResultsAria(searchResults.length, searchQuery)}
          >
            {searchResults.map((tour, index) => (
              <TourCardComponent
                key={tour.metadata.id}
                tour={tour}
                viewMode={viewMode}
                isWishlisted={wishlist.includes(tour.metadata.id)}
                onWishlistToggle={handleWishlistToggle}
                onQuickBook={handleQuickBook}
                onTourClick={() => handleTourClick(tour, index + 1)}
                position={index + 1}
                {...AriaManager.generateTourCardAria(tour, index + 1)}
              />
            ))}
          </div>
        )}
      </main>
      
      {/* Filter Drawer */}
      <FilterDrawer
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        filters={filters}
        onFiltersChange={handleFiltersChange}
        totalResults={searchResults.length}
      />
      
      {/* Lead Capture Modal */}
      <LeadCaptureModal
        isOpen={leadModal.isOpen}
        onClose={() => {
          setLeadModal({ isOpen: false })
          a11y.disableModalFocusTrap()
        }}
        tour={leadModal.tour}
      />
      
      {/* Sticky CTA (Mobile) */}
      {searchResults.length > 0 && (
        <div className="ts32-sticky-cta lg:hidden">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-600">
                พบ {searchResults.length} ทัวร์
              </div>
              <div className="text-lg font-bold text-blue-600">
                เริ่มต้น ฿{Math.min(...searchResults.map(t => t.pricing.base_price)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setShowFilters(true)}
                leftIcon={<Filter className="w-4 h-4" />}
              >
                ตัวกรอง
              </Button>
              
              <Button
                variant="primary"
                size="sm"
                leftIcon={<MessageCircle className="w-4 h-4" />}
                onClick={() => setLeadModal({ isOpen: true })}
              >
                สอบถาม
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Back to Top */}
      <button
        className={`ts32-back-to-top ${showBackToTop ? 'visible' : ''}`}
        onClick={scrollToTop}
        aria-label="กลับไปด้านบน"
      >
        <div className="w-12 h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center shadow-lg transition-colors">
          <ArrowUp className="w-5 h-5" />
        </div>
      </button>
    </div>
  )
}