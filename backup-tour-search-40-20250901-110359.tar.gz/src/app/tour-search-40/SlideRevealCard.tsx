'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { SearchIndexTour } from './types';
import { 
  Clock, MapPin, Star, Users, Heart, Calendar, ChevronDown, ChevronUp
} from 'lucide-react';

interface SlideRevealCardProps {
  tour: SearchIndexTour;
  isWishlisted?: boolean;
  onWishlistToggle?: (tourId: string) => void;
  onQuickBook?: (tour: SearchIndexTour) => void;
}

// Slide Reveal Card - เลื่อนเปิดข้อมูลแบบ Accordion
const SlideRevealCard: React.FC<SlideRevealCardProps> = ({ 
  tour, 
  isWishlisted = false, 
  onWishlistToggle, 
  onQuickBook 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  
  const formatPrice = (price: number) => price.toLocaleString('th-TH');
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0;

  // Generate unique image for each tour
  const getUniqueImage = () => {
    const tourIdHash = tour.metadata.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const images = [
      "https://images.unsplash.com/photo-1506197603052-3cc9c3a201bd?w=1200&q=95",
      "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=1200&q=95",
      "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1200&q=95",
      "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1200&q=95",
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&q=95",
      "https://images.unsplash.com/photo-1530789253388-582c481c54b0?w=1200&q=95",
      "https://images.unsplash.com/photo-1527004013197-933c4bb611b3?w=1200&q=95",
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=1200&q=95"
    ];
    return images[tourIdHash % images.length];
  };

  const getAirlineInfo = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'Thai Airways (TG)';
      case 'เกาหลีใต้': return 'Korean Air (KE)';
      case 'ไต้หวัน': return 'EVA Air (BR)';
      case 'ยุโรป': return 'Emirates (EK)';
      case 'จีน': return 'China Airlines (CI)';
      case 'สิงคโปร์': return 'Singapore Airlines (SQ)';
      case 'มาเลเซีย': return 'Malaysia Airlines (MH)';
      case 'ฮ่องกง': return 'Cathay Pacific (CX)';
      default: return 'Thai Airways (TG)';
    }
  };

  const getTravelPeriod = (country: string) => {
    switch (country) {
      case 'ญี่ปุ่น': return 'ก.ย. 68 – เม.ย. 69';
      case 'เกาหลีใต้': return 'ต.ค. 68 – มี.ค. 69';
      case 'ไต้หวัน': return 'ก.ย. 68 – ก.พ. 69';
      case 'ยุโรป': return 'เม.ย. 68 – ต.ค. 68';
      case 'จีน': return 'ตลอดปี';
      case 'สิงคโปร์': return 'ตลอดปี';
      case 'มาเลเซีย': return 'ตลอดปี';
      case 'ฮ่องกง': return 'ต.ค. 68 – เม.ย. 69';
      default: return 'ก.ย. 68 – ก.พ. 69';
    }
  };

  const handleToggle = () => {
    setIsAnimating(true);
    setIsExpanded(!isExpanded);
    setTimeout(() => setIsAnimating(false), 600);
  };

  return (
    <div className="relative mb-6">
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200 hover:shadow-xl transition-shadow duration-300">
        
        {/* Pre-Program View - Always Visible */}
        <div className="relative">
          <div className="relative h-64 overflow-hidden">
            <img
              src={getUniqueImage()}
              alt={tour.title}
              className="absolute inset-0 w-full h-full object-cover"
            />
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
            
            {/* Top Badges */}
            <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
              {hasDiscount && (
                <span className="bg-red-500 text-white text-xs px-3 py-1 rounded-full font-bold animate-pulse">
                  ลด {tour.pricing.discount_percentage}%
                </span>
              )}
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onWishlistToggle?.(tour.metadata.id);
                }}
                className="bg-white/90 backdrop-blur-sm rounded-full p-2 shadow-lg hover:bg-white transition-all ml-auto"
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
              </button>
            </div>
            
            {/* Bottom Content */}
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <h3 className="text-white text-2xl font-bold mb-2">
                {tour.title}
              </h3>
              
              <div className="flex items-center gap-4 text-white/90 text-sm mb-3">
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-1" />
                  {tour.location.country}
                </div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  {tour.duration_days} วัน {tour.nights} คืน
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-white text-2xl font-bold">
                    ฿{formatPrice(tour.pricing.base_price)}
                  </span>
                  {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                    <span className="text-white/70 text-sm line-through ml-2">
                      ฿{formatPrice(tour.pricing.original_price)}
                    </span>
                  )}
                </div>
                
                {/* Slide Toggle Button */}
                <button
                  onClick={handleToggle}
                  className="bg-white/90 backdrop-blur-sm text-gray-800 px-4 py-2 rounded-full font-medium text-sm hover:bg-white transition-all flex items-center gap-2 shadow-lg"
                >
                  <span>{isExpanded ? 'ซ่อนรายละเอียด' : 'คลิกดูโปรโมชั่น'}</span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4 animate-bounce" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Full Program View - Slide Down */}
        <div 
          className={`
            overflow-hidden transition-all duration-500 ease-in-out
            ${isExpanded ? 'max-h-[800px] opacity-100' : 'max-h-0 opacity-0'}
          `}
        >
          {/* Progress Indicator */}
          {isAnimating && (
            <div className="h-1 bg-gray-100">
              <div className="h-full bg-blue-500 animate-progress-bar" />
            </div>
          )}
          
          <div className="p-6 border-t border-gray-100">
            {/* Highlights */}
            <div className="mb-6">
              <h4 className="font-semibold text-gray-900 mb-3">ไฮไลท์ของทริป</h4>
              <div className="flex flex-wrap gap-2">
                {tour.highlights.slice(0, 5).map((highlight, idx) => (
                  <span key={idx} className="text-sm bg-blue-50 text-blue-700 px-3 py-1 rounded-full">
                    {typeof highlight === 'string' ? highlight : highlight.text}
                  </span>
                ))}
              </div>
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center bg-yellow-50 px-3 py-2 rounded-lg">
                <Star className="w-5 h-5 mr-1 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold">{tour.quality.rating}</span>
              </div>
              <span className="text-gray-500">({tour.quality.review_count} รีวิว)</span>
              <div className="flex items-center text-green-600">
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="font-medium">รีวิวจริง 100%</span>
              </div>
            </div>

            {/* Travel Info Grid */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-gray-600 text-sm">สายการบิน</span>
                  <div className="font-semibold text-gray-900">{getAirlineInfo(tour.location.country)}</div>
                </div>
                <div>
                  <span className="text-gray-600 text-sm">ช่วงเวลาเดินทาง</span>
                  <div className="font-semibold text-gray-900">{getTravelPeriod(tour.location.country)}</div>
                </div>
                <div>
                  <span className="text-gray-600 text-sm">ประเภททัวร์</span>
                  <div className="font-semibold text-gray-900">{tour.tour_type}</div>
                </div>
                <div>
                  <span className="text-gray-600 text-sm">รหัสทัวร์</span>
                  <div className="font-semibold text-gray-900">{tour.tour_code}</div>
                </div>
              </div>
            </div>

            {/* Cities */}
            {tour.location.cities && tour.location.cities.length > 0 && (
              <div className="mb-6">
                <h4 className="font-semibold text-gray-900 mb-3">เมืองที่เที่ยว</h4>
                <div className="flex flex-wrap gap-2">
                  {tour.location.cities.map((city, idx) => (
                    <span key={idx} className="text-sm bg-gray-100 text-gray-700 px-3 py-1 rounded-lg">
                      {city}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Price & CTA */}
            <div className="flex items-center justify-between pt-6 border-t border-gray-200">
              <div>
                <div className="text-3xl font-bold text-blue-600">
                  ฿{formatPrice(tour.pricing.base_price)}
                </div>
                <div className="text-sm text-gray-500">ต่อคน</div>
                {tour.pricing.original_price && tour.pricing.original_price > tour.pricing.base_price && (
                  <div className="text-sm text-green-600 font-medium mt-1">
                    ประหยัด ฿{formatPrice(tour.pricing.original_price - tour.pricing.base_price)}
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => onQuickBook?.(tour)}
                  className="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 px-6 rounded-xl font-medium hover:from-blue-600 hover:to-blue-700 transition-all shadow-lg"
                >
                  จองทันที
                </button>
                <Link href={tour.metadata.canonical_url}>
                  <button className="px-6 py-3 border-2 border-blue-500 text-blue-600 rounded-xl font-medium hover:bg-blue-50 transition-all">
                    ดูรายละเอียด
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Animation Styles */}
      <style jsx>{`
        @keyframes progress-bar {
          from {
            width: 0%;
          }
          to {
            width: 100%;
          }
        }
        
        .animate-progress-bar {
          animation: progress-bar 0.5s ease-out;
        }
      `}</style>
    </div>
  );
};

export default SlideRevealCard;