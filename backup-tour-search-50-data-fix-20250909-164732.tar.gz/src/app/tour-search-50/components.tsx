// ===================================================================
// tour-search-32: UI Primitives & Components
// ===================================================================
// Isolated, reusable components with full accessibility support
// Mobile-first design with comprehensive state handling

'use client'

import React, { useState, useEffect, useRef, forwardRef, useMemo } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { 
  Search, Filter, X, ChevronDown, ChevronUp, Star, Heart, 
  Clock, Users, MapPin, Calendar, Grid, List, Loader2,
  ArrowRight, Plus, Minus, Check, AlertCircle, MessageCircle, Zap, Mic, 
  Sparkles, TrendingUp, Globe
} from 'lucide-react'
import { TS32_TOKENS, TS32_COMPONENTS, TS32_CSS_VARS } from './design-system'
import { SearchIndexTour, SearchFilters, TourCard as TourCardType, FilterDrawer as FilterDrawerType } from './types'
import Prototype7TourCard from './Prototype7TourCard'
import ExactTourCard from './ExactTourCard'

// ===================================================================
// Flash Sale Components
// ===================================================================

interface FlashSaleTimerProps {
  endTime: string | Date
  onExpire?: () => void
}

export const FlashSaleTimer: React.FC<FlashSaleTimerProps> = ({ endTime, onExpire }) => {
  const [timeLeft, setTimeLeft] = useState<{
    hours: number
    minutes: number
    seconds: number
  }>({ hours: 0, minutes: 0, seconds: 0 })
  const [isExpired, setIsExpired] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    if (!isMounted) return

    const calculateTimeLeft = () => {
      const now = new Date().getTime()
      const end = new Date(endTime).getTime()
      const difference = end - now

      if (difference > 0) {
        const hours = Math.floor(difference / (1000 * 60 * 60))
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
        const seconds = Math.floor((difference % (1000 * 60)) / 1000)
        
        setTimeLeft({ hours, minutes, seconds })
        setIsExpired(false)
      } else {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0 })
        setIsExpired(true)
        onExpire?.()
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [endTime, onExpire, isMounted])

  if (!isMounted || isExpired) return null

  return (
    <div className="flex items-center space-x-1 text-white text-xs font-bold">
      <div className="flex items-center space-x-0.5">
        <div className="bg-white/20 px-1 py-0.5 rounded text-center min-w-[16px]">
          {String(timeLeft.hours).padStart(2, '0')}
        </div>
        <span className="text-white/80">:</span>
        <div className="bg-white/20 px-1 py-0.5 rounded text-center min-w-[16px]">
          {String(timeLeft.minutes).padStart(2, '0')}
        </div>
        <span className="text-white/80">:</span>
        <div className="bg-white/20 px-1 py-0.5 rounded text-center min-w-[16px]">
          {String(timeLeft.seconds).padStart(2, '0')}
        </div>
      </div>
    </div>
  )
}

interface FlashSaleBadgeProps {
  discount: number
  endTime: string | Date
  size?: 'sm' | 'md'
}

export const FlashSaleBadge: React.FC<FlashSaleBadgeProps> = ({ 
  discount, 
  endTime, 
  size = 'md' 
}) => {
  const sizeClasses = {
    sm: 'px-2.5 py-1.5 text-xs min-w-[100px]',
    md: 'px-3 py-2 text-sm min-w-[120px]'
  }

  return (
    <div className={`bg-gradient-to-r from-red-500 via-red-600 to-pink-600 text-white rounded-xl ${sizeClasses[size]} shadow-xl relative overflow-hidden border border-red-400/30`}>
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/20 to-transparent animate-pulse" />
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-yellow-300 to-orange-400" />
      
      <div className="relative z-10 flex flex-col items-center space-y-1">
        {/* Header */}
        <div className="flex items-center space-x-1.5 font-bold">
          <Zap className="w-3.5 h-3.5 text-yellow-300 drop-shadow-sm" />
          <span className="text-xs font-extrabold tracking-wide">FLASH SALE</span>
        </div>
        
        {/* Discount */}
        <div className="text-lg font-black text-yellow-200 drop-shadow-md leading-none">
          -{discount}%
        </div>
        
        {/* Timer */}
        <div className="bg-black/30 px-2 py-0.5 rounded-md backdrop-blur-sm">
          <FlashSaleTimer endTime={endTime} />
        </div>
      </div>
    </div>
  )
}

// ===================================================================
// Base UI Primitives
// ===================================================================

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'ghost'
  size?: 'sm' | 'md' | 'lg'
  isLoading?: boolean
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
  children: React.ReactNode
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', isLoading = false, leftIcon, rightIcon, children, className = '', ...props }, ref) => {
    const baseStyle = TS32_COMPONENTS.button.base
    const sizeStyle = TS32_COMPONENTS.button.sizes[size]
    const variantStyle = TS32_COMPONENTS.button.variants[variant]
    
    const buttonStyle: React.CSSProperties = {
      ...baseStyle,
      ...sizeStyle,
      ...variantStyle
    }
    
    return (
      <button
        ref={ref}
        className={`ts32-button ts32-button--${variant} ts32-button--${size} ${className}`}
        style={buttonStyle}
        disabled={isLoading || props.disabled}
        {...props}
      >
        {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
        {!isLoading && leftIcon && <span className="mr-2">{leftIcon}</span>}
        {children}
        {!isLoading && rightIcon && <span className="ml-2">{rightIcon}</span>}
      </button>
    )
  }
)
Button.displayName = 'Button'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, leftIcon, rightIcon, className = '', ...props }, ref) => {
    const baseStyle = TS32_COMPONENTS.input.base
    const hasError = Boolean(error)
    
    const inputStyle: React.CSSProperties = {
      ...baseStyle,
      paddingLeft: leftIcon ? TS32_TOKENS.spacing[10] : baseStyle.padding.split(' ')[1],
      paddingRight: rightIcon ? TS32_TOKENS.spacing[10] : baseStyle.padding.split(' ')[1]
    }
    
    return (
      <div className="ts32-input-wrapper">
        {label && (
          <label className="ts32-input-label block text-sm font-medium text-gray-700 mb-2">
            {label}
          </label>
        )}
        <div className="relative">
          {leftIcon && (
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
              {leftIcon}
            </div>
          )}
          <input
            ref={ref}
            className={`ts32-input ${className}`}
            style={inputStyle}
            aria-invalid={hasError}
            {...props}
          />
          {rightIcon && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
              {rightIcon}
            </div>
          )}
        </div>
        {error && (
          <p className="mt-1 text-sm text-red-600 flex items-center">
            <AlertCircle className="w-4 h-4 mr-1" />
            {error}
          </p>
        )}
      </div>
    )
  }
)
Input.displayName = 'Input'

interface BadgeProps {
  variant?: 'primary' | 'success' | 'warning' | 'error' | 'gray'
  children: React.ReactNode
  className?: string
}

export const Badge: React.FC<BadgeProps> = ({ variant = 'primary', children, className = '' }) => {
  const baseStyle = TS32_COMPONENTS.badge.base
  const variantStyle = TS32_COMPONENTS.badge.variants[variant]
  
  const badgeStyle: React.CSSProperties = {
    ...baseStyle,
    ...variantStyle
  }
  
  return (
    <span className={`ts32-badge ts32-badge--${variant} ${className}`} style={badgeStyle}>
      {children}
    </span>
  )
}

interface CardProps {
  variant?: 'base' | 'elevated' | 'interactive'
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export const Card: React.FC<CardProps> = ({ variant = 'base', children, className = '', onClick }) => {
  const baseStyle = TS32_COMPONENTS.card.base
  const variantStyle = variant !== 'base' ? TS32_COMPONENTS.card.variants[variant] : {}
  
  const cardStyle: React.CSSProperties = {
    ...baseStyle,
    ...variantStyle
  }
  
  // Always use div to avoid nested button issues
  return (
    <div
      className={`ts32-card ts32-card--${variant} ${className}`}
      style={cardStyle}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
    >
      {children}
    </div>
  )
}

interface SkeletonProps {
  width?: string
  height?: string
  className?: string
}

export const Skeleton: React.FC<SkeletonProps> = ({ width = '100%', height = '1rem', className = '' }) => {
  const skeletonStyle = TS32_COMPONENTS.skeleton.base
  
  return (
    <div 
      className={`ts32-skeleton ${className}`}
      style={{
        ...skeletonStyle,
        width,
        height
      }}
    />
  )
}

// ===================================================================
// Search Components
// ===================================================================

interface SearchBarProps {
  id?: string
  value: string
  onChange: (value: string) => void
  onSearch: (query: string) => void
  placeholder?: string
  suggestions?: string[]
  isLoading?: boolean
  enableVoiceSearch?: boolean
}

export const SearchBar: React.FC<SearchBarProps> = ({
  id,
  value,
  onChange,
  onSearch,
  placeholder = 'ค้นหาทัวร์, จุดหมาย, ประเทศ...',
  suggestions = [],
  isLoading = false,
  enableVoiceSearch = true
}) => {
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [animatedPlaceholder, setAnimatedPlaceholder] = useState('')
  const [isTypingAnimation, setIsTypingAnimation] = useState(false)
  const [isVoiceSearching, setIsVoiceSearching] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  
  const placeholderExamples = [
    'ทัวร์ญี่ปุ่น',
    'ทัวร์เกาหลี', 
    'ทัวร์ไต้หวัน',
    'ทัวร์ยุโรป',
    'ทัวร์สิงคโปร์'
  ]
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSearch(value)
    setShowSuggestions(false)
  }
  
  const handleSuggestionClick = (e: React.MouseEvent, suggestion: string) => {
    e.preventDefault()
    e.stopPropagation()
    onChange(suggestion)
    onSearch(suggestion)
    setShowSuggestions(false)
  }
  
  const handleClear = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    onChange('')
    setShowSuggestions(false)
    inputRef.current?.focus()
  }

  const handleVoiceSearch = () => {
    // Check for browser support
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
    
    if (!SpeechRecognition) {
      alert('เบราว์เซอร์ของคุณไม่รองรับการค้นหาด้วยเสียง')
      return
    }
    
    const recognition = new SpeechRecognition()
    
    // Configure recognition
    recognition.lang = 'th-TH' // Thai language
    recognition.continuous = false // Stop after getting result
    recognition.interimResults = false // Only final results
    recognition.maxAlternatives = 1
    
    setIsVoiceSearching(true)
    setShowSuggestions(false)
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript
      onChange(transcript)
      onSearch(transcript)
      setIsVoiceSearching(false)
    }
    
    recognition.onerror = (event: any) => {
      console.error('Voice recognition error:', event.error)
      setIsVoiceSearching(false)
      
      if (event.error === 'no-speech') {
        alert('ไม่ได้ยินเสียง กรุณาลองอีกครั้ง')
      } else if (event.error === 'not-allowed') {
        alert('กรุณาอนุญาตให้เข้าถึงไมโครโฟน')
      } else {
        alert('เกิดข้อผิดพลาดในการรับรู้เสียง กรุณาลองอีกครั้ง')
      }
    }
    
    recognition.onend = () => {
      setIsVoiceSearching(false)
    }
    
    recognition.start()
  }
  
  // Animated placeholder effect
  useEffect(() => {
    if (value.trim()) {
      setAnimatedPlaceholder('')
      setIsTypingAnimation(false)
      return
    }
    
    let currentIndex = 0
    let isDeleting = false
    let currentText = ''
    let timeoutId: NodeJS.Timeout
    
    const animatePlaceholder = () => {
      const currentExample = placeholderExamples[currentIndex]
      
      if (!isDeleting && currentText.length < currentExample.length) {
        // Typing animation
        setIsTypingAnimation(true)
        currentText += currentExample[currentText.length]
        setAnimatedPlaceholder(currentText)
        timeoutId = setTimeout(animatePlaceholder, 150) // Typing speed
      } else if (!isDeleting && currentText.length === currentExample.length) {
        // Pause after typing complete
        setIsTypingAnimation(false)
        timeoutId = setTimeout(() => {
          isDeleting = true
          animatePlaceholder()
        }, 3000) // Wait 3 seconds before deleting
      } else if (isDeleting && currentText.length > 0) {
        // Deleting animation
        setIsTypingAnimation(true)
        currentText = currentText.slice(0, -1)
        setAnimatedPlaceholder(currentText)
        timeoutId = setTimeout(animatePlaceholder, 100) // Deleting speed
      } else if (isDeleting && currentText.length === 0) {
        // Move to next example
        isDeleting = false
        currentIndex = (currentIndex + 1) % placeholderExamples.length
        timeoutId = setTimeout(animatePlaceholder, 500) // Pause before next word
      }
    }
    
    // Start animation after initial delay
    timeoutId = setTimeout(animatePlaceholder, 1000)
    
    return () => {
      if (timeoutId) clearTimeout(timeoutId)
    }
  }, [value])

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false)
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])
  
  return (
    <div ref={containerRef} className="ts32-search-bar relative">
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Input
            id={id}
            ref={inputRef}
            type="text"
            value={value}
            onChange={(e) => {
              onChange(e.target.value)
              setShowSuggestions(true)
            }}
            onFocus={() => setShowSuggestions(true)}
            placeholder={value.trim() ? placeholder : ''}
            leftIcon={<Search className="w-5 h-5" />}
            rightIcon={
              <div className="flex items-center space-x-1">
                {/* Voice Search Button */}
                {enableVoiceSearch && (
                  <button
                    type="button"
                    onClick={handleVoiceSearch}
                    disabled={isVoiceSearching}
                    className={`p-2 rounded-lg transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${
                      isVoiceSearching 
                        ? 'bg-red-100 text-red-600' 
                        : 'hover:bg-gray-100 text-gray-600'
                    }`}
                    aria-label="ค้นหาด้วยเสียง"
                  >
                    <Mic className={`w-5 h-5 ${isVoiceSearching ? 'animate-pulse' : ''}`} />
                  </button>
                )}
                {/* Loading or Clear Button */}
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : value.trim() ? (
                  <button
                    type="button"
                    onClick={handleClear}
                    className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                    aria-label="ล้างข้อความ"
                  >
                    <X className="w-4 h-4 text-gray-500 hover:text-gray-700" />
                  </button>
                ) : null}
              </div>
            }
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck="false"
          />
          
          {/* Animated Placeholder Overlay */}
          {!value.trim() && animatedPlaceholder && (
            <div 
              className="absolute left-10 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400 select-none"
              style={{ fontSize: '1rem' }}
            >
              {animatedPlaceholder}
              {!isTypingAnimation && (
                <span className="animate-pulse">|</span>
              )}
            </div>
          )}
        </div>
      </form>
      
      {/* Voice Search Status */}
      {isVoiceSearching && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-red-50 border-2 border-red-200 rounded-xl p-4 z-30">
          <div className="flex items-center gap-3 text-red-700">
            <Mic className="w-5 h-5 animate-pulse" />
            <span className="font-medium">กำลังฟัง... พูดชื่อจุดหมายที่ต้องการ</span>
          </div>
        </div>
      )}

      {/* Search Suggestions */}
      {showSuggestions && suggestions.length > 0 && !isVoiceSearching && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-[60]">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion}
              className="w-full text-left px-4 py-3 hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg cursor-pointer relative"
              onClick={(e) => handleSuggestionClick(e, suggestion)}
            >
              <div className="flex items-center">
                <Search className="w-4 h-4 mr-3 text-gray-400" />
                <span className="text-gray-900">{suggestion}</span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// ===================================================================
// Tour Card Component
// ===================================================================

interface TourCardComponentProps {
  tour: SearchIndexTour
  viewMode?: 'card' | 'list'
  showWishlist?: boolean
  showQuickBook?: boolean
  isWishlisted?: boolean
  onWishlistToggle?: (tourId: string) => void
  onQuickBook?: (tour: SearchIndexTour) => void
  isFirstCard?: boolean
  isCompact?: boolean
  compactVersion?: 'v1' | 'v2' | 'v3' | 'v4' | 'v5' | 'v6' | 'v7' | 'v8' | 'v9' | 'v10' | 'v11'
  onExpandToggle?: (tourId: string) => void
}

// Improved Tour Card Component with Better UX/UI
export const ImprovedTourCard: React.FC<{
  tour: SearchIndexTour;
  showTravelDates?: boolean;
  onToggleDates?: () => void;
  onBook?: () => void;
}> = ({ 
  tour, 
  showTravelDates = false, 
  onToggleDates, 
  onBook 
}) => {
  const formatPrice = (price: number) => price.toLocaleString('th-TH')
  
  // Generate realistic travel rounds data with holiday names
  const travelRounds = [
    { 
      month: 'ก.ย. 68', 
      dates: [
        { range: '2-6', holiday: 'วันหยุด' },
        { range: '10-14', holiday: 'ติดวันหยุด 3 วัน' }, 
        { range: '19-23', holiday: 'วันหยุดยาว' },
        { range: '26-30', holiday: 'ช่วงปลายเดือน' }
      ], 
      basePrice: tour.pricing.base_price, 
      availability: 'available', 
      color: 'emerald' 
    },
    { 
      month: 'ต.ค. 68', 
      dates: [
        { range: '4-8', holiday: 'วันหยุดยาว' },
        { range: '11-15', holiday: 'High Season' },
        { range: '22-26', holiday: 'ติดวันหยุด 5 วัน' },
        { range: '29-2 พ.ย.', holiday: 'วันหยุดพิเศษ' }
      ], 
      basePrice: tour.pricing.base_price + 2000, 
      availability: 'limited', 
      color: 'orange' 
    },
    { 
      month: 'พ.ย. 68', 
      dates: [
        { range: '5-9', holiday: 'Cool Season' },
        { range: '12-16', holiday: 'วันหยุด' },
        { range: '19-23', holiday: 'ติดวันหยุด 4 วัน' },
        { range: '26-30', holiday: 'ปลายปี' }
      ], 
      basePrice: tour.pricing.base_price + 1000, 
      availability: 'available', 
      color: 'blue' 
    }
  ]
  
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all duration-300 cursor-pointer group">
      {/* Hero Section */}
      <div className="relative">
        {/* Main Image - Larger and more prominent */}
        <div className="relative aspect-[16/10] overflow-hidden">
          <Image
            src={tour.media.hero_image}
            alt={tour.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-500"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          
          {/* Price Badge */}
          <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-lg">
            <div className="flex items-center gap-1">
              <span className="text-lg font-bold text-blue-600">฿{formatPrice(tour.pricing.base_price)}</span>
              <span className="text-sm text-gray-600">/คน</span>
            </div>
          </div>
          
          {/* Flash Sale Badge */}
          <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium animate-pulse">
            🔥 Flash Sale
          </div>
        </div>
        
        {/* Content Overlay */}
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="text-white font-bold text-xl mb-2 line-clamp-2 drop-shadow-lg">
            {tour.title}
          </h3>
          <div className="flex items-center text-white/90 text-sm">
            <MapPin className="w-4 h-4 mr-1" />
            <span>{tour.location.cities?.slice(0, 3).join(' • ') || tour.location.region || 'ไทเป • เชียงใหม่ • ภูเก็ต'}, {tour.location.country}</span>
          </div>
        </div>
      </div>
      
      {/* Content Section */}
      <div className="p-6">
        {/* Tour Highlights */}
        <div className="flex flex-wrap gap-2 mb-4">
          <div className="flex items-center bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm">
            <Clock className="w-4 h-4 mr-1" />
            <span>6 วัน 5 คืน</span>
          </div>
          <div className="flex items-center bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm">
            <Users className="w-4 h-4 mr-1" />
            <span>รวมมื้ออาหาร</span>
          </div>
          <div className="flex items-center bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-sm">
            <Star className="w-4 h-4 mr-1" />
            <span>4.8/5</span>
          </div>
        </div>
        
        {/* Travel Dates Section */}
        <div className="border-t pt-4">
          <button 
            className="flex items-center justify-between w-full p-4 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 transition-all duration-200 group/btn"
            onClick={onToggleDates}
          >
            <div className="flex items-center">
              <div className="flex items-center justify-center w-10 h-10 bg-blue-500 rounded-lg mr-3">
                <Calendar className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <div className="font-semibold text-gray-900">ช่วงเวลาเดินทาง</div>
                <div className="text-sm text-gray-600" dangerouslySetInnerHTML={{__html: `ก.ย. 68 - พ.ค.69<br />เริ่มต้น ฿${formatPrice(tour.pricing.base_price)}`}}></div>
              </div>
              <div className="ml-3 bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                มีที่ว่าง
              </div>
            </div>
            <ChevronDown className={`w-5 h-5 text-blue-600 transition-transform duration-200 group-hover/btn:text-blue-700 ${showTravelDates ? 'rotate-180' : ''}`} />
          </button>
          
          {/* Expandable Travel Dates */}
          {showTravelDates && (
            <div className="mt-4 space-y-3 max-h-80 overflow-y-auto overscroll-contain">
              {travelRounds.map((round, index) => (
                <div key={index} className="space-y-3">
                  <div className="mb-3">
                    {/* Minimal Elegant Design - Sticky Header */}
                    <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b border-gray-100 pb-2 mb-2 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-1 h-6 rounded-full bg-blue-500"></div>
                        <h4 className="text-lg font-semibold text-gray-900">{round.month}</h4>
                      </div>
                      <span className={`text-sm px-2 py-1 rounded ${
                        round.availability === 'available' 
                          ? 'text-blue-700 bg-blue-50' 
                          : 'text-blue-700 bg-blue-100'
                      }`}>
                        {round.availability === 'available' ? 'มีที่ว่าง' : 'เหลือน้อย'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {round.dates.map((date, dateIndex) => (
                      <div key={dateIndex} className="bg-white/90 backdrop-blur-sm rounded-xl border border-white/60 hover:bg-white hover:shadow-md transition-all duration-200 cursor-pointer group/date">
                        {/* Month Bar */}
                        <div className="w-full h-1 rounded-t-xl bg-gradient-to-r from-blue-400 to-indigo-500"></div>
                        
                        {/* Content */}
                        <div className="p-4">
                          <div className="flex justify-between items-center">
                            <div className="flex-1">
                              <div className="text-xl font-bold text-gray-900 mb-1">
                                {date.range} {round.month.split(' ')[0]}
                              </div>
                              <div className="text-xs flex items-center space-x-2">
                                <span className="text-orange-600 font-medium bg-orange-50 px-2 py-0.5 rounded">{date.holiday}</span>
                                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  round.availability === 'available' ? 'bg-green-100 text-green-700' :
                                  'bg-orange-100 text-orange-700'
                                }`}>
                                  {round.availability === 'available' ? 'มีที่ว่าง' : 'เหลือน้อย'}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold text-blue-600">฿{formatPrice(round.basePrice)}</div>
                              <div className="text-xs text-gray-500">ต่อคน</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              
              {/* Action Buttons */}
              <div className="flex gap-3 pt-4 border-t">
                <button 
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                  onClick={onToggleDates}
                >
                  ย่อ
                </button>
                <button 
                  className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 transform hover:scale-[1.02]"
                  onClick={onBook}
                >
                  เลือกวันเดินทาง
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// Modern Compact Tour Card - Using Prototype 7 from tour-search-42
export const CompactTourCard: React.FC<{
  tour: SearchIndexTour;
  onClick?: () => void;
  onBookClick?: () => void;
  variant?: 'minimal' | 'feature' | 'premium';
  isWishlisted?: boolean;
  onWishlistToggle?: (tourId: string) => void;
}> = ({ 
  tour, 
  onClick, 
  onBookClick,
  variant = 'minimal',
  isWishlisted = false,
  onWishlistToggle
}) => {
  // Use ExactTourCard copied from tour-search-47 exactly
  return (
    <ExactTourCard 
      tour={tour}
      isWishlisted={isWishlisted}
      onWishlistToggle={onWishlistToggle}
      onQuickBook={onBookClick ? () => onBookClick() : undefined}
    />
  )
}

export const TourCardComponent: React.FC<TourCardComponentProps> = ({
  tour,
  viewMode = 'card',
  showWishlist = true,
  showQuickBook = true,
  isWishlisted = false,
  onWishlistToggle,
  onQuickBook,
  isFirstCard = false,
  isCompact = false,
  compactVersion,
  onExpandToggle
}) => {
  const formatPrice = (price: number) => price.toLocaleString('th-TH')
  const hasDiscount = tour.pricing.discount_percentage && tour.pricing.discount_percentage > 0
  const discountSavings = hasDiscount ? 
    (tour.pricing.original_price || tour.pricing.base_price) - tour.pricing.base_price : 0
  
  // Get next available departure
  const nextDeparture = tour.availability.departure_dates.find(d => d.status !== 'soldout')
  
  // Flash Sale Logic - สุ่มให้บางทัวร์มี Flash Sale (25% chance)
  const tourId = tour.metadata.id
  const isFlashSale = useMemo(() => {
    // ใช้ tour ID เป็น seed เพื่อให้ Flash Sale คงที่
    const hash = tourId.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0)
      return a & a
    }, 0)
    return Math.abs(hash) % 4 === 0 // 25% chance
  }, [tourId])
  
  // Flash Sale end time (24 hours from fixed date to avoid hydration mismatch)
  const flashSaleEndTime = useMemo(() => {
    // Use a fixed future date to avoid hydration mismatch
    return new Date('2025-08-23T23:59:59Z')
  }, [])
  
  // Flash Sale discount (15-40%)
  const flashSaleDiscount = useMemo(() => {
    const hash = tourId.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0)
      return a & a
    }, 0)
    return 15 + (Math.abs(hash) % 26) // 15-40%
  }, [tourId])
  
  // Always use ExactTourCard for proper landmarks
  return (
    <ExactTourCard 
      tour={tour}
      isWishlisted={isWishlisted}
      onWishlistToggle={onWishlistToggle}
      onQuickBook={onQuickBook}
    />
  )
}

// ===================================================================
// View Toggle Component
// ===================================================================

interface ViewToggleProps {
  viewMode: 'card' | 'list'
  onChange: (mode: 'card' | 'list') => void
}

// Removed duplicate ViewToggle and old TourCardComponent code

// ===================================================================
// Sort Dropdown Component
// ===================================================================

interface SortOption {
  value: string
  label: string
  description?: string
}

interface SortDropdownProps {
  options: SortOption[]
  value: string
  onChange: (value: string) => void
}

export const SortDropdown: React.FC<SortDropdownProps> = ({ options, value, onChange }) => {
  const [isOpen, setIsOpen] = useState(false)
  const selectedOption = options.find(option => option.value === value)
  
  return (
    <div className="relative">
      <Button
        variant="secondary"
        onClick={() => setIsOpen(!isOpen)}
        rightIcon={<ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />}
      >
        {selectedOption?.label || 'เรียงตาม'}
      </Button>
      
      {isOpen && (
        <div className="absolute top-full right-0 mt-1 w-64 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
          {options.map((option) => (
            <button
              key={option.value}
              className="w-full text-left px-4 py-3 hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg"
              onClick={() => {
                onChange(option.value)
                setIsOpen(false)
              }}
            >
              <div className="font-medium text-gray-900">{option.label}</div>
              {option.description && (
                <div className="text-sm text-gray-500 mt-1">{option.description}</div>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// ===================================================================
// Loading States
// ===================================================================

export const TourCardSkeleton: React.FC<{ viewMode?: 'card' | 'list' }> = ({ viewMode = 'card' }) => {
  if (viewMode === 'list') {
    return (
      <Card className="mb-4">
        <div className="flex p-4">
          <Skeleton width="96px" height="96px" className="rounded-lg flex-shrink-0" />
          <div className="flex-1 ml-4">
            <Skeleton width="70%" height="1.25rem" className="mb-2" />
            <Skeleton width="50%" height="1rem" className="mb-3" />
            <div className="flex justify-between items-center">
              <Skeleton width="80px" height="1.5rem" />
              <Skeleton width="100px" height="2rem" />
            </div>
          </div>
        </div>
      </Card>
    )
  }
  
  return (
    <Card>
      <Skeleton width="100%" height="192px" className="mb-4" />
      <div className="p-4">
        <Skeleton width="90%" height="1.25rem" className="mb-3" />
        <Skeleton width="60%" height="1rem" className="mb-4" />
        <div className="flex gap-2 mb-4">
          <Skeleton width="60px" height="1.5rem" />
          <Skeleton width="70px" height="1.5rem" />
          <Skeleton width="50px" height="1.5rem" />
        </div>
        <div className="flex justify-between items-center pt-4 border-t border-gray-100">
          <Skeleton width="80px" height="2rem" />
          <Skeleton width="120px" height="2.5rem" />
        </div>
      </div>
    </Card>
  )
}

export const SearchResultsSkeleton: React.FC<{ count?: number; viewMode?: 'card' | 'list' }> = ({ 
  count = 8, 
  viewMode = 'card'
}) => {
  return (
    <div className={viewMode === 'card' 
      ? 'grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
      : 'space-y-4'
    }>
      {Array.from({ length: count }).map((_, index) => (
        <TourCardSkeleton key={index} viewMode={viewMode} />
      ))}
    </div>
  )
}

// ===================================================================
// View Toggle Component  
// ===================================================================

export const ViewToggle: React.FC<{ viewMode: 'card' | 'list'; onChange: (mode: 'card' | 'list') => void }> = ({ viewMode, onChange }) => {
  return (
    <div className="flex bg-gray-100 rounded-lg p-1">
      <Button
        variant={viewMode === 'card' ? 'primary' : 'ghost'}
        size="sm"
        onClick={() => onChange('card')}
        className="!min-w-[40px] !h-[36px]"
        aria-label="มุมมองการ์ด"
      >
        <Grid className="w-4 h-4" />
      </Button>
      <Button
        variant={viewMode === 'list' ? 'primary' : 'ghost'}
        size="sm"
        onClick={() => onChange('list')}
        className="!min-w-[40px] !h-[36px]"
        aria-label="มุมมองรายการ"
      >
        <List className="w-4 h-4" />
      </Button>
    </div>
  )
}

export default {
  FlashSaleTimer,
  FlashSaleBadge,
  Button,
  Input,
  Badge,
  Card,
  Skeleton,
  SearchBar,
  TourCardComponent,
  ImprovedTourCard,
  CompactTourCard,
  ViewToggle,
  SortDropdown,
  TourCardSkeleton,
  SearchResultsSkeleton
}
