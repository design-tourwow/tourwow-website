// ===================================================================
// tour-search-50: Data ETL System (Fixed Version)
// ===================================================================
// Extract, Transform, Load data with local imports only

import { SearchIndexTour, DepartureDate, TourHighlight, SearchFilters, SearchSortOptions } from './types'
import { localTours as allTours } from './tours-data-local'

// ===================================================================
// Extract: Data sources from existing implementations
// ===================================================================

class TourDataETL {
  transformToSearchIndex(tour: any, index: number): SearchIndexTour {
    const sourcePage: '13' | '21' = index % 3 === 0 ? '21' : '13'
    
    // Generate unique tour metadata
    const tourId = `tour-${String(index).padStart(3, '0')}`
    const slug = tour.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-') || tourId
    
    // Extract location data
    const location = {
      country: tour.location || 'ไทย',
      country_code: this.getCountryCode(tour.location || 'ไทย'),
      region: 'เอเชีย',
      cities: [tour.location || 'กรุงเทพ'],
      coordinates: {
        lat: 13.7563,
        lng: 100.5018
      }
    }

    // Generate pricing information
    const basePrice = tour.price || 25000
    const originalPrice = tour.originalPrice || Math.floor(basePrice * 1.2)
    const discountPercentage = Math.floor(((originalPrice - basePrice) / originalPrice) * 100)

    // Create SearchIndexTour object
    const searchIndexTour: SearchIndexTour = {
      metadata: {
        id: tourId,
        slug: slug,
        canonical_url: `/tour-search-50/${slug}`,
        source_page: sourcePage,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        featured: index % 5 === 0,
        priority_score: Math.random() * 100,
        search_keywords: this.generateSearchKeywords(tour),
        seo_title: tour.title,
        seo_description: tour.description
      },
      
      title: tour.title || 'ทัวร์สุดพิเศษ',
      description: tour.description || 'ท่องเที่ยวสุดประทับใจ',
      duration_days: tour.duration || 5,
      nights: tour.nights || 4,
      
      location: location,
      
      pricing: {
        base_price: basePrice,
        currency: 'THB',
        original_price: originalPrice,
        discount_percentage: discountPercentage > 0 ? discountPercentage : undefined,
        promotion_text: discountPercentage > 0 ? `ลด ${discountPercentage}%` : undefined,
        price_includes: ['ตั้งวงอาหาร', 'ที่พักโรงแรม', 'รถทัวร์ปรับอากาศ'],
        price_excludes: ['ตั๋วเครื่องบิน', 'วีซ่า', 'ทิปคนขับ'],
        deposit_required: Math.floor(basePrice * 0.3),
        payment_terms: 'จ่ายเงินมัดจำ 30% ที่เหลือก่อนเดินทาง'
      },
      
      quality: {
        rating: tour.rating || 4.0,
        review_count: tour.reviews || 50,
        satisfaction_score: (tour.rating || 4.0) * 20,
        trust_score: 85,
        completion_rate: 98,
        repeat_customers: 25
      },
      
      highlights: this.generateHighlights(tour),
      tags: ['ทัวร์', 'ท่องเที่ยว', location.country],
      themes: ['วัฒนธรรม', 'ธรรมชาติ', 'อาหาร'],
      
      media: {
        hero_image: tour.image || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=1200&q=95',
        gallery_images: this.generateGalleryImages(tour.image),
        video_url: undefined,
        virtual_tour_url: undefined,
        alt_texts: [tour.title || 'ภาพทัวร์']
      },
      
      availability: {
        available_seats: Math.floor(Math.random() * 20) + 10,
        total_capacity: 40,
        min_group_size: 15,
        max_group_size: 40,
        departure_dates: this.generateDepartureDates(),
        booking_deadline_days: 7,
        cancellation_policy: 'ยกเลิกได้ก่อนเดินทาง 14 วัน'
      },
      
      search_text: `${tour.title} ${tour.description} ${location.country}`,
      popularity_score: Math.random() * 100,
      conversion_rate: 0.05 + Math.random() * 0.1
    }

    return searchIndexTour
  }

  private getCountryCode(country: string): string {
    const codes: { [key: string]: string } = {
      'ญี่ปุ่น': 'jp',
      'เกาหลีใต้': 'kr', 
      'ไต้หวัน': 'tw',
      'จีน': 'cn',
      'ไทย': 'th'
    }
    return codes[country] || 'th'
  }

  private generateSearchKeywords(tour: any): string[] {
    const keywords = [tour.title?.split(' ') || [], ['ทัวร์', 'ท่องเที่ยว']]
    return keywords.flat().filter(Boolean)
  }

  private generateHighlights(tour: any): TourHighlight[] {
    const defaultHighlights = tour.highlights || ['สถานที่ท่องเที่ยวสำคัญ', 'อาหารท้องถิน', 'วัฒนธรรมดั้งเดิม']
    
    return defaultHighlights.map((highlight: string, index: number) => ({
      id: `highlight-${index}`,
      text: highlight,
      icon: '🎯',
      category: 'attraction' as const
    }))
  }

  private generateGalleryImages(heroImage: string): string[] {
    return [
      heroImage,
      'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=1200&q=95',
      'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=1200&q=95'
    ].filter(Boolean)
  }

  private generateDepartureDates(): DepartureDate[] {
    const dates: DepartureDate[] = []
    const today = new Date()
    
    for (let i = 1; i <= 6; i++) {
      const departureDate = new Date(today)
      departureDate.setMonth(today.getMonth() + i)
      
      const endDate = new Date(departureDate)
      endDate.setDate(departureDate.getDate() + 5)
      
      dates.push({
        id: `departure-${i}`,
        date_range: `${departureDate.toLocaleDateString('th')} - ${endDate.toLocaleDateString('th')}`,
        start_date: departureDate,
        end_date: endDate,
        price: 25000 + Math.floor(Math.random() * 10000),
        available_seats: Math.floor(Math.random() * 15) + 5,
        total_seats: 40,
        status: Math.random() > 0.7 ? 'low' : 'available',
        special_notes: i === 1 ? 'โปรโมชั่นพิเศษ' : undefined
      })
    }
    
    return dates
  }
}

// ===================================================================
// SearchIndex Manager (Singleton)
// ===================================================================

class SearchIndexManager {
  private static instance: SearchIndexManager
  private tours: SearchIndexTour[] = []
  private isDataLoaded = false

  constructor() {
    this.loadData()
  }
  
  private async loadData(): Promise<void> {
    try {
      // Use local tours data (already imported at top)
      const etl = new TourDataETL()
      
      // Transform legacy tours to SearchIndex format
      this.tours = (allTours || []).map((tour, index) => {
        return etl.transformToSearchIndex(tour, index)
      })
      
      this.isDataLoaded = true
      
    } catch (error) {
      console.error('❌ Failed to load tour data:', error)
      this.tours = []
      this.isDataLoaded = false
    }
  }

  static getInstance(): SearchIndexManager {
    if (!SearchIndexManager.instance) {
      SearchIndexManager.instance = new SearchIndexManager()
    }
    return SearchIndexManager.instance
  }

  search(filters?: SearchFilters, sortOptions?: SearchSortOptions, page = 1, perPage = 12) {
    if (!this.isDataLoaded) {
      return {
        tours: [],
        total_count: 0,
        page,
        per_page: perPage,
        filters_applied: filters || {},
        sort_applied: sortOptions || { field: 'popularity', direction: 'desc' },
        search_time_ms: 0,
        suggestions: []
      }
    }

    let filtered = [...this.tours]
    const startTime = Date.now()

    // Apply filters
    if (filters?.query) {
      const query = filters.query.toLowerCase()
      filtered = filtered.filter(tour => 
        tour.search_text.toLowerCase().includes(query) ||
        tour.title.toLowerCase().includes(query)
      )
    }

    if (filters?.countries?.length) {
      filtered = filtered.filter(tour => 
        filters.countries!.includes(tour.location.country)
      )
    }

    if (filters?.price_min !== undefined) {
      filtered = filtered.filter(tour => tour.pricing.base_price >= filters.price_min!)
    }

    if (filters?.price_max !== undefined) {
      filtered = filtered.filter(tour => tour.pricing.base_price <= filters.price_max!)
    }
    
    // Sort results
    if (sortOptions) {
      filtered.sort((a, b) => {
        let comparison = 0
        
        switch (sortOptions.field) {
          case 'popularity':
            comparison = b.popularity_score - a.popularity_score
            break
          case 'price':
            comparison = a.pricing.base_price - b.pricing.base_price
            break
          case 'rating':
            comparison = b.quality.rating - a.quality.rating
            break
          case 'duration':
            comparison = a.duration_days - b.duration_days
            break
          default:
            comparison = b.popularity_score - a.popularity_score
        }
        
        return sortOptions.direction === 'desc' ? comparison : -comparison
      })
    }

    // Pagination
    const startIndex = (page - 1) * perPage
    const endIndex = startIndex + perPage
    const paginatedTours = filtered.slice(startIndex, endIndex)

    const searchTime = Date.now() - startTime

    return {
      tours: paginatedTours,
      total_count: filtered.length,
      page,
      per_page: perPage,
      filters_applied: filters || {},
      sort_applied: sortOptions || { field: 'popularity', direction: 'desc' },
      search_time_ms: searchTime,
      suggestions: []
    }
  }

  getAllTours(): SearchIndexTour[] {
    return this.tours
  }

  getTourById(id: string): SearchIndexTour | undefined {
    return this.tours.find(tour => tour.metadata.id === id)
  }

  getPopularDestinations(): Array<{ name: string; count: number; image: string }> {
    const countryMap = new Map<string, { count: number; image: string }>()
    
    this.tours.forEach(tour => {
      const country = tour.location.country
      const current = countryMap.get(country)
      if (current) {
        current.count++
      } else {
        countryMap.set(country, {
          count: 1,
          image: tour.media.hero_image
        })
      }
    })

    return Array.from(countryMap.entries())
      .map(([name, data]) => ({ name, count: data.count, image: data.image }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6)
  }

  getFeaturedTours(): SearchIndexTour[] {
    return this.tours
      .filter(tour => tour.metadata.featured)
      .slice(0, 6)
  }
}

// Create and export singleton instance
export const searchIndex = SearchIndexManager.getInstance()

export default SearchIndexManager
export { SearchIndexManager }
export type { SearchIndexTour, SearchFilters, SearchSortOptions }